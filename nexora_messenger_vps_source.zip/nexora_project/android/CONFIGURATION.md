# Nexora Android — Configuración

## 1. Firebase

Coloca tu archivo real en:

```text
android/app/google-services.json
```

No necesitas terminal para “configurarlo”; Android Studio/Gradle lo detecta al compilar con el plugin de Google Services.

## 2. Backend propio VPS

La app usa `BuildConfig.RELAY_BASE_URL` para hablar con tu servidor.

Compila con:

```bash
./gradlew :app:assembleDebug -PNEXORA_RELAY_BASE_URL=https://api.TU-DOMINIO.com
```

Para release:

```bash
./gradlew :app:assembleRelease -PNEXORA_RELAY_BASE_URL=https://api.TU-DOMINIO.com
```

## 3. Pruebas locales

El proyecto permite HTTP solo para `localhost`, `127.0.0.1` y `10.0.2.2`. Para producción usa HTTPS obligatorio mediante Nginx + Certbot.

## 4. Variables importantes

- `NEXORA_RELAY_BASE_URL`: URL pública del VPS.
- `google-services.json`: Firebase Auth y FCM.

## 5. Qué sigue usando Firebase

- OTP por número de teléfono.
- ID Token para autenticar contra el VPS.
- FCM para notificaciones.

El relay de mensajes, la cola cifrada y los avatares viven en tu VPS con PostgreSQL y almacenamiento persistente local.
