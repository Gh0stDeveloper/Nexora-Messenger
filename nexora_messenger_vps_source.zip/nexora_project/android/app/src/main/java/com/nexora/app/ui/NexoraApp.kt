package com.nexora.app.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.rememberNavController
import com.nexora.app.ui.navigation.NexoraNavHost

@Composable
fun NexoraApp() {
    val navController = rememberNavController()
    NexoraNavHost(navController = navController)
}
