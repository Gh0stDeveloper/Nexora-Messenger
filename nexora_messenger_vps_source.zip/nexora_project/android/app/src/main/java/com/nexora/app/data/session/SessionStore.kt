package com.nexora.app.data.session

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SessionStore @Inject constructor(
    @ApplicationContext context: Context,
) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _currentUserId = MutableStateFlow(prefs.getString(KEY_UID, null))
    val currentUserId: StateFlow<String?> = _currentUserId.asStateFlow()

    private val _currentPhone = MutableStateFlow(prefs.getString(KEY_PHONE, null))
    val currentPhone: StateFlow<String?> = _currentPhone.asStateFlow()

    fun setCurrentUserId(uid: String?) {
        _currentUserId.value = uid
        prefs.edit().apply {
            if (uid == null) remove(KEY_UID) else putString(KEY_UID, uid)
        }.apply()
    }

    fun setCurrentPhone(phone: String?) {
        _currentPhone.value = phone
        prefs.edit().apply {
            if (phone == null) remove(KEY_PHONE) else putString(KEY_PHONE, phone)
        }.apply()
    }

    fun clear() {
        setCurrentUserId(null)
        setCurrentPhone(null)
    }

    companion object {
        private const val PREFS_NAME = "nexora_session"
        private const val KEY_UID = "current_uid"
        private const val KEY_PHONE = "current_phone"
    }
}
