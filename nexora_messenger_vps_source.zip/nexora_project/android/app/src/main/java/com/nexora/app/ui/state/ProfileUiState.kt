package com.nexora.app.ui.state

data class ProfileUiState(
    val isSaving: Boolean = false,
    val name: String = "",
    val photoUrl: String = "",
    val error: String? = null,
)
