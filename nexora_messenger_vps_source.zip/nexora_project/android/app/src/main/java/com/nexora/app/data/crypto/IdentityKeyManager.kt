package com.nexora.app.data.crypto

interface IdentityKeyManager {
    fun getOrCreatePublicKeyBase64(): String
}
