package com.nexora.app.di

import android.content.Context
import androidx.room.Room
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.nexora.app.data.crypto.AesGcmCryptoManager
import com.nexora.app.data.crypto.AndroidIdentityKeyManager
import com.nexora.app.data.crypto.CryptoManager
import com.nexora.app.data.crypto.IdentityKeyManager
import com.nexora.app.data.local.NexoraDatabase
import com.nexora.app.data.local.dao.ChatDao
import com.nexora.app.data.local.dao.MessageDao
import com.nexora.app.data.local.dao.UserDao
import com.nexora.app.data.repository.FirebaseAuthRepository
import com.nexora.app.data.repository.FirebaseUserRepository
import com.nexora.app.data.repository.RemoteRelayChatRepository
import com.nexora.app.data.repository.LocalStoryRepository
import com.nexora.app.data.session.SessionStore
import com.nexora.app.domain.repository.AuthRepository
import com.nexora.app.domain.repository.ChatRepository
import com.nexora.app.domain.repository.StoryRepository
import com.nexora.app.domain.repository.UserRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class AppBindings {
    @Binds abstract fun bindAuthRepository(impl: FirebaseAuthRepository): AuthRepository
    @Binds abstract fun bindUserRepository(impl: FirebaseUserRepository): UserRepository
    @Binds abstract fun bindChatRepository(impl: RemoteRelayChatRepository): ChatRepository
    @Binds abstract fun bindStoryRepository(impl: LocalStoryRepository): StoryRepository
    @Binds abstract fun bindCryptoManager(impl: AesGcmCryptoManager): CryptoManager
    @Binds abstract fun bindIdentityKeyManager(impl: AndroidIdentityKeyManager): IdentityKeyManager
}

@Module
@InstallIn(SingletonComponent::class)
object AppProviders {
    @Provides @Singleton fun provideFirebaseAuth(): FirebaseAuth = FirebaseAuth.getInstance()
    @Provides @Singleton fun provideFirestore(): FirebaseFirestore = FirebaseFirestore.getInstance()

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): NexoraDatabase =
        Room.databaseBuilder(context, NexoraDatabase::class.java, "nexora.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun provideUserDao(db: NexoraDatabase): UserDao = db.userDao()
    @Provides fun provideChatDao(db: NexoraDatabase): ChatDao = db.chatDao()
    @Provides fun provideMessageDao(db: NexoraDatabase): MessageDao = db.messageDao()

    @Provides @Singleton fun provideSessionStore(@ApplicationContext context: Context): SessionStore = SessionStore(context)
}
