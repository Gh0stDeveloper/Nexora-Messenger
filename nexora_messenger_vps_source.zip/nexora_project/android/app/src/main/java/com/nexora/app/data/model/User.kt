package com.nexora.app.data.model

data class User(
    val uid: String = "",
    val phone: String = "",
    val name: String = "",
    val photoUrl: String? = null,
    val status: String = "Disponible",
    val lastSeen: Long = 0L,
    val publicKey: String? = null,
)
