package com.nexora.app.ui.viewmodel

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexora.app.data.remote.OtpEvent
import com.nexora.app.domain.usecase.RequestOtpUseCase
import com.nexora.app.domain.usecase.VerifyOtpUseCase
import com.nexora.app.ui.state.LoginUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val requestOtpUseCase: RequestOtpUseCase,
    private val verifyOtpUseCase: VerifyOtpUseCase,
) : ViewModel() {
    private val _uiState = MutableStateFlow<LoginUiState>(LoginUiState.Idle)
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

    fun requestOtp(activity: Activity, phone: String) = viewModelScope.launch {
        _uiState.value = LoginUiState.Loading
        requestOtpUseCase(activity, phone).collect { event ->
            _uiState.value = when (event) {
                is OtpEvent.CodeSent -> LoginUiState.OtpSent(event.verificationId)
                is OtpEvent.Verified -> LoginUiState.Success(event.uid)
                is OtpEvent.Error -> LoginUiState.Error(event.message)
            }
        }
    }

    fun verifyOtp(verificationId: String, code: String) = viewModelScope.launch {
        _uiState.value = LoginUiState.Loading
        _uiState.value = verifyOtpUseCase(verificationId, code).fold(
            onSuccess = { LoginUiState.Success(it) },
            onFailure = { LoginUiState.Error(it.message ?: "Código inválido") },
        )
    }
}
