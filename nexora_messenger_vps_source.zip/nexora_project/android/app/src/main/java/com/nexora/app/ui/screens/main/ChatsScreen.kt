package com.nexora.app.ui.screens.main

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexora.app.data.model.Chat
import com.nexora.app.ui.viewmodel.ChatsViewModel
import com.nexora.app.util.timeLabel

@Composable
fun ChatsScreen(
    modifier: Modifier = Modifier,
    onOpenChat: (chatId: String, title: String, peerId: String) -> Unit = { _, _, _ -> },
    viewModel: ChatsViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    Column(modifier = modifier.fillMaxSize().padding(16.dp)) {
        Text("Chats", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        if (state.isLoading) {
            CircularProgressIndicator()
        } else if (state.chats.isEmpty()) {
            EmptyChatsState()
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(state.chats, key = { it.chatId }) { chat ->
                    ChatRow(chat = chat, onOpenChat = onOpenChat)
                }
            }
        }
    }
}

@Composable
private fun ChatRow(
    chat: Chat,
    onOpenChat: (chatId: String, title: String, peerId: String) -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onOpenChat(chat.chatId, chat.peerName, chat.peerId) },
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Column(modifier = Modifier.weight(1f)) {
                Text(chat.peerName.ifBlank { "Contacto" }, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(chat.lastMessagePreview, style = MaterialTheme.typography.bodyMedium)
            }
            Text(timeLabel(chat.lastMessageTimestamp), style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun EmptyChatsState() {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Aún no hay conversaciones", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text("Cuando envíes o recibas mensajes cifrados, aparecerán aquí y se guardarán localmente en el dispositivo.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            AssistChip(onClick = { }, label = { Text("Relay cifrado listo") })
        }
    }
}
