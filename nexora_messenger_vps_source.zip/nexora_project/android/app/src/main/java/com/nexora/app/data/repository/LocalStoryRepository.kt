package com.nexora.app.data.repository

import com.nexora.app.data.model.Story
import com.nexora.app.domain.repository.StoryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LocalStoryRepository @Inject constructor() : StoryRepository {
    private val stories = MutableStateFlow(
        listOf(
            Story(
                id = "story_1",
                ownerId = "nexora_bot",
                ownerName = "Nexora Bot",
                mediaUrl = "https://example.com",
                caption = "Estados efímeros de ejemplo",
                createdAt = System.currentTimeMillis(),
                expiresAt = System.currentTimeMillis() + 24 * 60 * 60 * 1000,
            )
        )
    )

    override fun observeStories(): Flow<List<Story>> = stories.asStateFlow()
}
