package com.nexora.app.domain.repository

import com.nexora.app.data.model.Story
import kotlinx.coroutines.flow.Flow

interface StoryRepository {
    fun observeStories(): Flow<List<Story>>
}
