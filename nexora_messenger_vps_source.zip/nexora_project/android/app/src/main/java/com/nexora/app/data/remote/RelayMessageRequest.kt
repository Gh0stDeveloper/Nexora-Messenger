package com.nexora.app.data.remote

import org.json.JSONObject

data class RelayMessageRequest(
    val chatId: String,
    val messageId: String,
    val senderId: String,
    val recipientId: String,
    val kind: String,
    val encryptedPayload: String,
    val iv: String,
    val timestamp: Long,
    val protocolVersion: String = "nexora-e2ee-v1",
    val expiresAtEpochMs: Long? = null,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("chatId", chatId)
        put("messageId", messageId)
        put("senderId", senderId)
        put("recipientId", recipientId)
        put("kind", kind)
        put("encryptedPayload", encryptedPayload)
        put("iv", iv)
        put("timestamp", timestamp)
        put("protocolVersion", protocolVersion)
        put("expiresAtEpochMs", expiresAtEpochMs)
    }
}
