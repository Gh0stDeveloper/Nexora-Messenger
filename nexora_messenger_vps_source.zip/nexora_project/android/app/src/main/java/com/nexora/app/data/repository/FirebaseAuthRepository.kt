package com.nexora.app.data.repository

import android.app.Activity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.nexora.app.data.crypto.IdentityKeyManager
import com.nexora.app.data.remote.OtpEvent
import com.nexora.app.data.session.SessionStore
import com.nexora.app.util.await
import com.nexora.app.domain.repository.AuthRepository
import com.nexora.app.domain.repository.UserRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FirebaseAuthRepository @Inject constructor(
    private val auth: FirebaseAuth,
    private val sessionStore: SessionStore,
    private val userRepository: UserRepository,
    private val identityKeyManager: IdentityKeyManager,
) : AuthRepository {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override val currentUserId: StateFlow<String?> = sessionStore.currentUserId
    override val currentPhone: StateFlow<String?> = sessionStore.currentPhone

    override fun requestOtp(activity: Activity, phoneE164: String): Flow<OtpEvent> = callbackFlow {
        sessionStore.setCurrentPhone(phoneE164)

        val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: com.google.firebase.auth.PhoneAuthCredential) {
                auth.signInWithCredential(credential)
                    .addOnSuccessListener { result ->
                        val uid = result.user?.uid
                        if (uid != null) {
                            scope.launch {
                                val publicKey = identityKeyManager.getOrCreatePublicKeyBase64()
                                userRepository.ensureUser(uid, phoneE164, publicKey)
                            }
                            sessionStore.setCurrentUserId(uid)
                            trySend(OtpEvent.Verified(uid))
                        } else {
                            trySend(OtpEvent.Error("No se pudo resolver la sesión"))
                        }
                    }
                    .addOnFailureListener { error ->
                        trySend(OtpEvent.Error(error.message ?: "No se pudo verificar automáticamente"))
                    }
            }

            override fun onVerificationFailed(e: com.google.firebase.FirebaseException) {
                trySend(OtpEvent.Error(e.message ?: "No se pudo enviar el código"))
            }

            override fun onCodeSent(
                verificationId: String,
                token: PhoneAuthProvider.ForceResendingToken,
            ) {
                trySend(OtpEvent.CodeSent(verificationId))
            }
        }

        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phoneE164)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(callbacks)
            .build()

        PhoneAuthProvider.verifyPhoneNumber(options)
        awaitClose { }
    }

    override suspend fun verifyOtp(verificationId: String, code: String): Result<String> = runCatching {
        val credential = PhoneAuthProvider.getCredential(verificationId, code)
        val result = auth.signInWithCredential(credential).await()
        val uid = result.user?.uid ?: error("UID vacío")
        val phone = sessionStore.currentPhone.value.orEmpty()
        val publicKey = identityKeyManager.getOrCreatePublicKeyBase64()
        userRepository.ensureUser(uid, phone, publicKey).getOrThrow()
        sessionStore.setCurrentUserId(uid)
        uid
    }

    override suspend fun saveProfile(uid: String, name: String, photoUrl: String?): Result<Unit> = runCatching {
        val phone = currentPhone.value.orEmpty()
        require(phone.isNotBlank()) { "No hay número asociado a la sesión" }
        val publicKey = identityKeyManager.getOrCreatePublicKeyBase64()
        userRepository.saveProfile(uid, phone, name, photoUrl, publicKey).getOrThrow()
    }

    override suspend fun signOut() {
        auth.signOut()
        sessionStore.clear()
    }
}
