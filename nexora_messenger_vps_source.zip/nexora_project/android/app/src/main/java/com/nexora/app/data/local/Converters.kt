package com.nexora.app.data.local

import androidx.room.TypeConverter
import com.nexora.app.data.model.MessageKind

class Converters {
    @TypeConverter
    fun toKind(value: String): MessageKind = runCatching { MessageKind.valueOf(value) }.getOrDefault(MessageKind.TEXT)

    @TypeConverter
    fun fromKind(kind: MessageKind): String = kind.name
}
