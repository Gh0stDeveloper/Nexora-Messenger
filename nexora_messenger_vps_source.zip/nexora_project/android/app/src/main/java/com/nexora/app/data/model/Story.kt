package com.nexora.app.data.model

data class Story(
    val id: String = "",
    val ownerId: String = "",
    val ownerName: String = "",
    val mediaUrl: String = "",
    val caption: String? = null,
    val createdAt: Long = 0L,
    val expiresAt: Long = 0L,
    val visibility: String = "all_contacts",
)
