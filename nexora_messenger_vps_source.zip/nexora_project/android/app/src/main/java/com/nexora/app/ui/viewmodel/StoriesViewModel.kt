package com.nexora.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexora.app.domain.usecase.ObserveStoriesUseCase
import com.nexora.app.ui.state.StoriesUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class StoriesViewModel @Inject constructor(
    private val observeStoriesUseCase: ObserveStoriesUseCase,
) : ViewModel() {
    private val _uiState = MutableStateFlow(StoriesUiState())
    val uiState: StateFlow<StoriesUiState> = _uiState.asStateFlow()

    fun load() = viewModelScope.launch {
        observeStoriesUseCase().collect { stories ->
            _uiState.value = StoriesUiState(isLoading = false, stories = stories)
        }
    }
}
