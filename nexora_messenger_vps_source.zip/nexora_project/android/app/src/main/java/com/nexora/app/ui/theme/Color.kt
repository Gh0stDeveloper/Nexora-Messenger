package com.nexora.app.ui.theme

import androidx.compose.ui.graphics.Color

val NexoraPrimary = Color(0xFF7C4DFF)
val NexoraSecondary = Color(0xFF00D1B2)
val NexoraBackground = Color(0xFF0B0F1A)
val NexoraSurface = Color(0xFF121826)
