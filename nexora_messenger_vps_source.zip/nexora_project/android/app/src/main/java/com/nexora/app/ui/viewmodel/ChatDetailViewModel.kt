package com.nexora.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexora.app.domain.usecase.ObserveMessagesUseCase
import com.nexora.app.domain.usecase.SendTextMessageUseCase
import com.nexora.app.ui.state.ChatDetailUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ChatDetailViewModel @Inject constructor(
    private val observeMessagesUseCase: ObserveMessagesUseCase,
    private val sendTextMessageUseCase: SendTextMessageUseCase,
) : ViewModel() {
    private val _uiState = MutableStateFlow(ChatDetailUiState())
    val uiState: StateFlow<ChatDetailUiState> = _uiState.asStateFlow()

    fun load(chatId: String, peerId: String, title: String) = viewModelScope.launch {
        _uiState.value = _uiState.value.copy(chatTitle = title, peerId = peerId)
        observeMessagesUseCase(chatId).collect { messages ->
            _uiState.value = _uiState.value.copy(isLoading = false, messages = messages)
        }
    }

    fun onDraftChanged(value: String) {
        _uiState.value = _uiState.value.copy(draft = value)
    }

    fun send(chatId: String, senderId: String, recipientId: String) = viewModelScope.launch {
        val text = _uiState.value.draft.trim()
        if (text.isBlank()) return@launch
        sendTextMessageUseCase(chatId, senderId, recipientId, text)
        _uiState.value = _uiState.value.copy(draft = "")
    }
}
