package com.nexora.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val chatId: String,
    val senderId: String,
    val recipientId: String,
    val kind: String,
    val encryptedPayload: String,
    val iv: String,
    val timestamp: Long,
    val delivered: Boolean,
    val read: Boolean,
)
