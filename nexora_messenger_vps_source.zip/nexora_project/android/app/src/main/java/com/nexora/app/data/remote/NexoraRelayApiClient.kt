package com.nexora.app.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NexoraRelayApiClient @Inject constructor() {

    suspend fun bootstrapUser(
        baseUrl: String,
        idToken: String,
        name: String? = null,
        phone: String? = null,
        photoUrl: String? = null,
        publicKey: String? = null,
        fcmToken: String? = null,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            postJson(
                url = "$baseUrl/v1/relay/users/me/bootstrap",
                bearerToken = idToken,
                body = JSONObject().apply {
                    put("name", name)
                    put("phone", phone)
                    put("photoUrl", photoUrl)
                    put("publicKey", publicKey)
                    put("fcmToken", fcmToken)
                },
            )
        }
    }

    suspend fun updateFcmToken(
        baseUrl: String,
        idToken: String,
        token: String,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            postJson(
                url = "$baseUrl/v1/relay/users/me/fcm-token",
                bearerToken = idToken,
                body = JSONObject().apply { put("token", token) },
            )
        }
    }

    suspend fun uploadAvatar(
        baseUrl: String,
        idToken: String,
        fileName: String,
        mimeType: String,
        bytes: ByteArray,
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val response = postMultipart(
                url = "$baseUrl/v1/relay/users/me/avatar",
                bearerToken = idToken,
                fieldName = "avatar",
                fileName = fileName,
                mimeType = mimeType,
                bytes = bytes,
            )
            JSONObject(response).getString("photoUrl")
        }
    }

    suspend fun sendMessage(
        baseUrl: String,
        idToken: String,
        request: RelayMessageRequest,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            postJson(
                url = "$baseUrl/v1/relay/messages",
                bearerToken = idToken,
                body = request.toJson(),
            )
        }
    }

    suspend fun fetchChats(
        baseUrl: String,
        idToken: String,
        limit: Int = 100,
    ): Result<JSONObject> = withContext(Dispatchers.IO) {
        runCatching {
            val response = getJson("$baseUrl/v1/relay/chats?limit=$limit", idToken)
            JSONObject(response)
        }
    }

    suspend fun fetchMessagesSince(
        baseUrl: String,
        idToken: String,
        chatId: String,
        since: Long? = null,
        limit: Int = 200,
    ): Result<JSONObject> = withContext(Dispatchers.IO) {
        runCatching {
            val params = buildString {
                append("limit=").append(limit)
                if (since != null && since > 0L) append("&since=").append(since)
            }
            val url = "$baseUrl/v1/relay/chats/$chatId/messages?$params"
            val response = getJson(url, idToken)
            JSONObject(response)
        }
    }

    private fun postJson(url: String, bearerToken: String, body: JSONObject) {
        val conn = openConnection(url, bearerToken, "POST")
        conn.doOutput = true
        conn.outputStream.use { output ->
            output.write(body.toString().toByteArray(Charsets.UTF_8))
        }
        val code = conn.responseCode
        val bodyText = if (code in 200..299) readBody(conn) else readErrorBody(conn)
        conn.disconnect()
        if (code !in 200..299) {
            throw IllegalStateException("Relay rejected request (${code}): $bodyText")
        }
    }

    private fun postMultipart(
        url: String,
        bearerToken: String,
        fieldName: String,
        fileName: String,
        mimeType: String,
        bytes: ByteArray,
    ): String {
        val boundary = "NexoraBoundary${UUID.randomUUID()}"
        val conn = openConnection(url, bearerToken, "POST")
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        DataOutputStream(conn.outputStream).use { output ->
            output.writeBytes("--$boundary\r\n")
            output.writeBytes("Content-Disposition: form-data; name=\"$fieldName\"; filename=\"$fileName\"\r\n")
            output.writeBytes("Content-Type: $mimeType\r\n")
            output.writeBytes("\r\n")
            output.write(bytes)
            output.writeBytes("\r\n")
            output.writeBytes("--$boundary--\r\n")
            output.flush()
        }
        val code = conn.responseCode
        val bodyText = if (code in 200..299) readBody(conn) else readErrorBody(conn)
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException("Relay rejected avatar (${code}): $bodyText")
        return bodyText
    }

    private fun getJson(url: String, bearerToken: String): String {
        val conn = openConnection(url, bearerToken, "GET")
        val code = conn.responseCode
        val body = if (code in 200..299) readBody(conn) else readErrorBody(conn)
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException("Relay rejected request (${code}): $body")
        return body
    }

    private fun openConnection(url: String, bearerToken: String, method: String): HttpURLConnection {
        return (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 15_000
            readTimeout = 30_000
            setRequestProperty("Authorization", "Bearer $bearerToken")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("X-Request-Id", UUID.randomUUID().toString())
            setRequestProperty("User-Agent", "Nexora-Android")
        }
    }

    private fun readBody(conn: HttpURLConnection): String {
        val stream = conn.inputStream ?: conn.errorStream
        return stream?.bufferedReader()?.use(BufferedReader::readText).orEmpty()
    }

    private fun readErrorBody(conn: HttpURLConnection): String = conn.errorStream?.bufferedReader()?.use(BufferedReader::readText).orEmpty()
}
