package com.nexora.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.messaging.FirebaseMessaging
import com.nexora.app.domain.repository.AuthRepository
import com.nexora.app.domain.repository.UserRepository
import com.nexora.app.domain.usecase.SaveProfileUseCase
import com.nexora.app.ui.state.ProfileUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProfileSetupViewModel @Inject constructor(
    private val saveProfileUseCase: SaveProfileUseCase,
    private val authRepository: AuthRepository,
    private val userRepository: UserRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    fun onNameChanged(value: String) {
        _uiState.value = _uiState.value.copy(name = value)
    }

    fun onPhotoChanged(value: String) {
        _uiState.value = _uiState.value.copy(photoUrl = value)
    }

    fun save(onFinished: (String) -> Unit) = viewModelScope.launch {
        val uid = authRepository.currentUserId.value ?: return@launch
        val phone = authRepository.currentPhone.value.orEmpty()
        val current = _uiState.value
        if (current.name.isBlank()) {
            _uiState.value = current.copy(error = "El nombre es obligatorio")
            return@launch
        }
        _uiState.value = current.copy(isSaving = true, error = null)
        val result = saveProfileUseCase(uid, phone, current.name.trim(), current.photoUrl.ifBlank { null })
        _uiState.value = _uiState.value.copy(isSaving = false)
        result.fold(
            onSuccess = {
                FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
                    viewModelScope.launch { userRepository.saveFcmToken(uid, token) }
                }
                onFinished(uid)
            },
            onFailure = { _uiState.value = _uiState.value.copy(error = it.message ?: "No se pudo guardar") },
        )
    }
}
