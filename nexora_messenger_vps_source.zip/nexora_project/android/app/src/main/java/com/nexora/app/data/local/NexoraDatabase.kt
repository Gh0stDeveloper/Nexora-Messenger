package com.nexora.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.nexora.app.data.local.dao.ChatDao
import com.nexora.app.data.local.dao.MessageDao
import com.nexora.app.data.local.dao.UserDao
import com.nexora.app.data.local.entity.ChatEntity
import com.nexora.app.data.local.entity.MessageEntity
import com.nexora.app.data.local.entity.UserEntity

@Database(
    entities = [UserEntity::class, ChatEntity::class, MessageEntity::class],
    version = 1,
    exportSchema = false,
)
@TypeConverters(Converters::class)
abstract class NexoraDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun chatDao(): ChatDao
    abstract fun messageDao(): MessageDao
}
