package com.nexora.app.data.remote

sealed interface OtpEvent {
    data class CodeSent(val verificationId: String) : OtpEvent
    data class Verified(val uid: String) : OtpEvent
    data class Error(val message: String) : OtpEvent
}
