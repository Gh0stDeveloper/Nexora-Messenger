package com.nexora.app.data.local.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.nexora.app.data.local.entity.ChatEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Upsert
    suspend fun upsert(chat: ChatEntity)

    @Query("SELECT * FROM chats WHERE ownerId = :uid OR peerId = :uid ORDER BY lastMessageTimestamp DESC")
    fun observeForUser(uid: String): Flow<List<ChatEntity>>

    @Query("SELECT * FROM chats WHERE chatId = :chatId LIMIT 1")
    fun observe(chatId: String): Flow<ChatEntity?>

    @Query("SELECT * FROM chats WHERE chatId = :chatId LIMIT 1")
    suspend fun get(chatId: String): ChatEntity?
}
