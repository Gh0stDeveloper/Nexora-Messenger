package com.nexora.app.ui.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.nexora.app.ui.screens.auth.LoginScreen
import com.nexora.app.ui.screens.auth.ProfileSetupScreen
import com.nexora.app.ui.screens.auth.SplashScreen
import com.nexora.app.ui.screens.main.ChatDetailScreen
import com.nexora.app.ui.screens.main.ChatsScreen
import com.nexora.app.ui.screens.main.MainScaffold
import com.nexora.app.ui.screens.main.SettingsScreen
import com.nexora.app.ui.screens.main.StoriesScreen
import com.nexora.app.ui.viewmodel.AppViewModel

@Composable
fun NexoraNavHost(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Routes.SPLASH) {
        composable(Routes.SPLASH) {
            val vm: AppViewModel = hiltViewModel()
            val state = vm.uiState.value
            SplashScreen()
            LaunchedEffect(state.currentUserId, state.profileComplete) {
                val destination = when {
                    state.currentUserId == null -> Routes.LOGIN
                    state.profileComplete -> Routes.MAIN
                    else -> Routes.PROFILE_SETUP
                }
                navController.navigate(destination) {
                    popUpTo(Routes.SPLASH) { inclusive = true }
                }
            }
        }

        composable(Routes.LOGIN) {
            LoginScreen(
                onOtpVerified = {
                    navController.navigate(Routes.PROFILE_SETUP) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.PROFILE_SETUP) {
            ProfileSetupScreen(
                onFinished = {
                    navController.navigate(Routes.MAIN) {
                        popUpTo(Routes.PROFILE_SETUP) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.MAIN) {
            MainScaffold(
                onOpenChat = { chatId, title, peerId ->
                    navController.navigate("${Routes.CHAT_DETAIL}/$chatId/${Uri.encode(title)}/$peerId")
                },
                onLogout = {
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(Routes.MAIN) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.CHATS) {
            ChatsScreen(onOpenChat = { chatId, title, peerId ->
                navController.navigate("${Routes.CHAT_DETAIL}/$chatId/${Uri.encode(title)}/$peerId")
            })
        }
        composable(Routes.STORIES) { StoriesScreen() }
        composable(Routes.SETTINGS) { SettingsScreen(onLogout = {
            navController.navigate(Routes.LOGIN) { popUpTo(Routes.MAIN) { inclusive = true } }
        }) }
        composable(
            route = "${Routes.CHAT_DETAIL}/{chatId}/{title}/{peerId}",
            arguments = listOf(
                navArgument("chatId") { type = NavType.StringType },
                navArgument("title") { type = NavType.StringType },
                navArgument("peerId") { type = NavType.StringType },
            )
        ) { entry ->
            val chatId = entry.arguments?.getString("chatId").orEmpty()
            val title = entry.arguments?.getString("title").orEmpty().let(Uri::decode)
            val peerId = entry.arguments?.getString("peerId").orEmpty()
            ChatDetailScreen(chatId = chatId, title = title, peerId = peerId, onBack = { navController.popBackStack() })
        }
    }
}
