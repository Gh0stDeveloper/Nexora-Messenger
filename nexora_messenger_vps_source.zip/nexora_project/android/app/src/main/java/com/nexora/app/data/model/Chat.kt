package com.nexora.app.data.model

data class Chat(
    val chatId: String = "",
    val ownerId: String = "",
    val peerId: String = "",
    val peerName: String = "",
    val peerPhotoUrl: String? = null,
    val lastMessagePreview: String = "",
    val lastMessageTimestamp: Long = 0L,
    val lastMessageSenderId: String = "",
    val unreadCount: Int = 0,
    val isGroup: Boolean = false,
    val groupName: String? = null,
    val groupPhotoUrl: String? = null,
)
