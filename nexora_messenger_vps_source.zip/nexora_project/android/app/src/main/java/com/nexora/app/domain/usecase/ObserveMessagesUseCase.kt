package com.nexora.app.domain.usecase

import com.nexora.app.domain.repository.ChatRepository
import javax.inject.Inject

class ObserveMessagesUseCase @Inject constructor(
    private val chatRepository: ChatRepository,
) {
    operator fun invoke(chatId: String) = chatRepository.observeMessages(chatId)
}
