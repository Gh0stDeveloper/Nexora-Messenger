package com.nexora.app.ui.screens.main

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CloudDone
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.nexora.app.ui.viewmodel.SettingsViewModel

@Composable
fun SettingsScreen(
    onLogout: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel(),
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Ajustes", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
        Text("Perfil, seguridad y privacidad", color = MaterialTheme.colorScheme.onSurfaceVariant)

        SecurityInfoCard(
            icon = { Icon(Icons.Outlined.Lock, contentDescription = null) },
            title = "Cifrado activo",
            body = "Los mensajes se envían como payload cifrado. El relay no guarda texto plano ni vistas previas reales.",
        )
        SecurityInfoCard(
            icon = { Icon(Icons.Outlined.CloudDone, contentDescription = null) },
            title = "Relay VPS",
            body = "El backend de tu VPS valida el token de Firebase antes de aceptar mensajes y solo guarda ciphertext en PostgreSQL.",
        )
        SecurityInfoCard(
            icon = { Icon(Icons.Outlined.Notifications, contentDescription = null) },
            title = "Notificaciones privadas",
            body = "Las notificaciones muestran contenido genérico para no exponer mensajes en la pantalla bloqueada.",
        )

        Spacer(Modifier.height(8.dp))
        Button(onClick = { viewModel.signOut(onLogout) }, modifier = Modifier.fillMaxWidth()) {
            Text("Cerrar sesión")
        }
    }
}

@Composable
private fun SecurityInfoCard(
    icon: @Composable () -> Unit,
    title: String,
    body: String,
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            icon()
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
