package com.nexora.app.data.repository

import android.content.Context
import android.net.Uri
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.nexora.app.BuildConfig
import com.nexora.app.data.local.dao.UserDao
import com.nexora.app.data.local.entity.UserEntity
import com.nexora.app.data.model.User
import com.nexora.app.data.remote.NexoraRelayApiClient
import com.nexora.app.domain.repository.UserRepository
import com.nexora.app.util.await
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FirebaseUserRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth,
    private val relayApiClient: NexoraRelayApiClient,
    private val userDao: UserDao,
    @ApplicationContext private val context: Context,
) : UserRepository {

    override fun observeUser(uid: String): Flow<User?> = callbackFlow {
        val listener = firestore.collection(USERS).document(uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val user = snapshot?.toUser()
                if (user != null) trySend(user)
            }
        awaitClose { listener.remove() }
    }

    override suspend fun upsert(user: User): Result<Unit> = runCatching {
        firestore.collection(USERS).document(user.uid)
            .set(user.toFirestoreMap(), com.google.firebase.firestore.SetOptions.merge())
            .await()
        userDao.upsert(user.toEntity())
    }

    override suspend fun ensureUser(uid: String, phone: String, publicKey: String?): Result<Unit> = runCatching {
        val existing = firestore.collection(USERS).document(uid).get().await().toUser()
        val baseline = existing ?: User(
            uid = uid,
            phone = phone,
            name = "",
            photoUrl = null,
            status = "Disponible",
            lastSeen = System.currentTimeMillis(),
            publicKey = publicKey,
        )
        firestore.collection(USERS).document(uid).set(
            baseline.copy(
                phone = phone,
                publicKey = publicKey ?: baseline.publicKey,
                lastSeen = System.currentTimeMillis(),
            ).toFirestoreMap(),
            com.google.firebase.firestore.SetOptions.merge(),
        ).await()
        userDao.upsert(baseline.copy(phone = phone, publicKey = publicKey ?: baseline.publicKey).toEntity())
        bootstrapOnVps(
            name = baseline.name,
            phone = phone,
            photoUrl = baseline.photoUrl,
            publicKey = publicKey ?: baseline.publicKey,
            fcmToken = null,
        )
    }

    override suspend fun saveProfile(
        uid: String,
        phone: String,
        name: String,
        photoUrl: String?,
        publicKey: String?,
    ): Result<Unit> = runCatching {
        val payload = mapOf(
            "uid" to uid,
            "phone" to phone,
            "name" to name,
            "photoUrl" to photoUrl,
            "status" to "Disponible",
            "lastSeen" to FieldValue.serverTimestamp(),
            "publicKey" to publicKey,
            "profileCompleted" to true,
            "updatedAt" to FieldValue.serverTimestamp(),
        )
        firestore.collection(USERS).document(uid)
            .set(payload, com.google.firebase.firestore.SetOptions.merge())
            .await()
        userDao.upsert(
            UserEntity(
                uid = uid,
                phone = phone,
                name = name,
                photoUrl = photoUrl,
                status = "Disponible",
                lastSeen = System.currentTimeMillis(),
                publicKey = publicKey,
                updatedAt = System.currentTimeMillis(),
            ),
        )
        bootstrapOnVps(name = name, phone = phone, photoUrl = photoUrl, publicKey = publicKey, fcmToken = null)
    }

    override suspend fun uploadAvatar(uid: String, localUri: String): Result<String> = runCatching {
        val idToken = auth.currentUser?.getIdToken(false)?.await()?.token ?: error("Sesión no disponible")
        val uri = Uri.parse(localUri)
        val mimeType = context.contentResolver.getType(uri)?.takeIf { it.startsWith("image/") } ?: "image/jpeg"
        val bytes = context.contentResolver.openInputStream(uri)?.use { input -> input.readBytes() }
            ?: error("No se pudo abrir la imagen")
        require(bytes.size <= MAX_AVATAR_BYTES) { "La imagen debe pesar máximo 2 MB" }
        val extension = when (mimeType) {
            "image/png" -> "png"
            "image/webp" -> "webp"
            else -> "jpg"
        }
        relayApiClient.uploadAvatar(
            baseUrl = relayBaseUrl(),
            idToken = idToken,
            fileName = "avatar-$uid.$extension",
            mimeType = mimeType,
            bytes = bytes,
        ).getOrThrow()
    }

    override suspend fun saveFcmToken(uid: String, token: String): Result<Unit> = runCatching {
        firestore.collection(FCM_TOKENS).document(uid).set(
            mapOf(
                "token" to token,
                "platform" to "android",
                "updatedAt" to FieldValue.serverTimestamp(),
            ),
            com.google.firebase.firestore.SetOptions.merge(),
        ).await()
        val idToken = auth.currentUser?.getIdToken(false)?.await()?.token
        if (!idToken.isNullOrBlank()) {
            relayApiClient.updateFcmToken(relayBaseUrl(), idToken, token).getOrNull()
        }
    }

    private suspend fun bootstrapOnVps(
        name: String?,
        phone: String?,
        photoUrl: String?,
        publicKey: String?,
        fcmToken: String?,
    ) {
        val idToken = auth.currentUser?.getIdToken(false)?.await()?.token ?: return
        relayApiClient.bootstrapUser(
            baseUrl = relayBaseUrl(),
            idToken = idToken,
            name = name,
            phone = phone,
            photoUrl = photoUrl,
            publicKey = publicKey,
            fcmToken = fcmToken,
        ).getOrNull()
    }

    private fun relayBaseUrl(): String = BuildConfig.RELAY_BASE_URL.trim().trimEnd('/')

    private fun User.toFirestoreMap(): Map<String, Any?> = mapOf(
        "uid" to uid,
        "phone" to phone,
        "name" to name,
        "photoUrl" to photoUrl,
        "status" to status,
        "lastSeen" to lastSeen,
        "publicKey" to publicKey,
        "profileCompleted" to name.isNotBlank(),
        "updatedAt" to FieldValue.serverTimestamp(),
    )

    private fun com.google.firebase.firestore.DocumentSnapshot.toUser(): User? {
        if (!exists()) return null
        return User(
            uid = getString("uid") ?: id,
            phone = getString("phone").orEmpty(),
            name = getString("name").orEmpty(),
            photoUrl = getString("photoUrl"),
            status = getString("status") ?: "Disponible",
            lastSeen = getEpochMillis("lastSeen"),
            publicKey = getString("publicKey"),
        )
    }

    private fun com.google.firebase.firestore.DocumentSnapshot.getEpochMillis(field: String): Long {
        return when (val value = get(field)) {
            is Long -> value
            is Int -> value.toLong()
            is Double -> value.toLong()
            is Timestamp -> value.toDate().time
            else -> 0L
        }
    }

    private fun User.toEntity(): UserEntity = UserEntity(
        uid = uid,
        phone = phone,
        name = name,
        photoUrl = photoUrl,
        status = status,
        lastSeen = lastSeen,
        publicKey = publicKey,
        updatedAt = System.currentTimeMillis(),
    )

    companion object {
        private const val USERS = "users"
        private const val FCM_TOKENS = "fcmTokens"
        private const val MAX_AVATAR_BYTES = 2 * 1024 * 1024
    }
}
