package com.nexora.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val uid: String,
    val phone: String,
    val name: String,
    val photoUrl: String?,
    val status: String,
    val lastSeen: Long,
    val publicKey: String?,
    val updatedAt: Long,
)
