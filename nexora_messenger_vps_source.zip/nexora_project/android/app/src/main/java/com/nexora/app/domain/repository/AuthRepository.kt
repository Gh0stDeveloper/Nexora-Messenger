package com.nexora.app.domain.repository

import android.app.Activity
import com.nexora.app.data.remote.OtpEvent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

interface AuthRepository {
    val currentUserId: StateFlow<String?>
    val currentPhone: StateFlow<String?>
    fun requestOtp(activity: Activity, phoneE164: String): Flow<OtpEvent>
    suspend fun verifyOtp(verificationId: String, code: String): Result<String>
    suspend fun saveProfile(uid: String, name: String, photoUrl: String?): Result<Unit>
    suspend fun signOut()
}
