package com.nexora.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey val chatId: String,
    val ownerId: String,
    val peerId: String,
    val peerName: String,
    val peerPhotoUrl: String?,
    val lastMessagePreview: String,
    val lastMessageTimestamp: Long,
    val lastMessageSenderId: String,
    val unreadCount: Int,
    val isGroup: Boolean = false,
    val groupName: String? = null,
    val groupPhotoUrl: String? = null,
)
