package com.nexora.app.util

object PhoneNumberValidator {
    private val e164 = Regex("^\+[1-9]\d{7,14}$")
    fun isValid(phone: String): Boolean = e164.matches(phone.trim())
}
