package com.nexora.app.data.messaging

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.nexora.app.data.repository.FirebaseUserRepository
import com.nexora.app.notification.NexoraNotifier
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class NexoraMessagingService : FirebaseMessagingService() {
    @Inject lateinit var userRepository: FirebaseUserRepository
    @Inject lateinit var notifier: NexoraNotifier
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        serviceScope.launch { userRepository.saveFcmToken(uid, token) }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        notifier.showEncryptedMessage(
            chatId = message.data["chatId"],
            messageId = message.data["messageId"],
        )
    }
}
