package com.nexora.app.ui.state

data class AppUiState(
    val currentUserId: String? = null,
    val profileComplete: Boolean = false,
)
