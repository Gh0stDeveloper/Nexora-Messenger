package com.nexora.app.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.nexora.app.BuildConfig
import com.nexora.app.data.crypto.CryptoManager
import com.nexora.app.data.crypto.EncryptedPayload
import com.nexora.app.data.local.dao.ChatDao
import com.nexora.app.data.local.dao.MessageDao
import com.nexora.app.data.local.entity.ChatEntity
import com.nexora.app.data.local.entity.MessageEntity
import com.nexora.app.data.model.Chat
import com.nexora.app.data.model.Message
import com.nexora.app.data.model.MessageKind
import com.nexora.app.data.remote.NexoraRelayApiClient
import com.nexora.app.data.remote.RelayMessageRequest
import com.nexora.app.domain.repository.ChatRepository
import com.nexora.app.util.await
import com.nexora.app.util.chatIdForUsers
import com.nexora.app.util.previewFromPlainText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RemoteRelayChatRepository @Inject constructor(
    @Suppress("unused") private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth,
    private val relayApiClient: NexoraRelayApiClient,
    private val chatDao: ChatDao,
    private val messageDao: MessageDao,
    private val cryptoManager: CryptoManager,
) : ChatRepository {

    override fun observeChats(uid: String): Flow<List<Chat>> = channelFlow {
        val syncJob = launch(Dispatchers.IO) {
            while (isActive) {
                syncChats(uid)
                delay(CHAT_SYNC_INTERVAL_MS)
            }
        }

        val localJob = launch {
            chatDao.observeForUser(uid).map { list -> list.map { it.toDomain() } }.collect { send(it) }
        }

        awaitClose {
            syncJob.cancel()
            localJob.cancel()
        }
    }

    override fun observeMessages(chatId: String): Flow<List<Message>> = channelFlow {
        val syncJob = launch(Dispatchers.IO) {
            while (isActive) {
                syncMessages(chatId)
                delay(MESSAGE_SYNC_INTERVAL_MS)
            }
        }

        val localJob = launch {
            messageDao.observeForChat(chatId).map { list ->
                list.map { entity ->
                    val text = runCatching {
                        cryptoManager.decrypt(
                            EncryptedPayload(
                                cipherTextBase64 = entity.encryptedPayload,
                                ivBase64 = entity.iv,
                            )
                        )
                    }.getOrDefault("[Mensaje cifrado]")
                    entity.toDomain(text)
                }
            }.collect { send(it) }
        }

        awaitClose {
            syncJob.cancel()
            localJob.cancel()
        }
    }

    override suspend fun sendTextMessage(
        chatId: String,
        senderId: String,
        recipientId: String,
        plainText: String,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(auth.currentUser?.uid == senderId) { "La sesión activa no coincide con el remitente" }
            val encrypted = cryptoManager.encrypt(plainText)
            val now = System.currentTimeMillis()
            val messageId = "msg_${now}_${UUID.randomUUID().toString().take(8)}"
            val request = RelayMessageRequest(
                chatId = chatId.ifBlank { chatIdForUsers(senderId, recipientId) },
                messageId = messageId,
                senderId = senderId,
                recipientId = recipientId,
                kind = MessageKind.TEXT.name,
                encryptedPayload = encrypted.cipherTextBase64,
                iv = encrypted.ivBase64,
                timestamp = now,
            )

            val localMessage = MessageEntity(
                id = messageId,
                chatId = request.chatId,
                senderId = senderId,
                recipientId = recipientId,
                kind = MessageKind.TEXT.name,
                encryptedPayload = encrypted.cipherTextBase64,
                iv = encrypted.ivBase64,
                timestamp = now,
                delivered = false,
                read = false,
            )
            messageDao.upsert(localMessage)

            val existingChat = chatDao.get(request.chatId)
            val chat = existingChat ?: ChatEntity(
                chatId = request.chatId,
                ownerId = senderId,
                peerId = recipientId,
                peerName = "Contacto",
                peerPhotoUrl = null,
                lastMessagePreview = previewFromPlainText(plainText),
                lastMessageTimestamp = now,
                lastMessageSenderId = senderId,
                unreadCount = 0,
            )
            chatDao.upsert(
                chat.copy(
                    lastMessagePreview = previewFromPlainText(plainText),
                    lastMessageTimestamp = now,
                    lastMessageSenderId = senderId,
                )
            )

            val token = auth.currentUser?.getIdToken(false)?.await()?.token
                ?: error("No fue posible obtener el token de sesión")
            relayApiClient.sendMessage(
                baseUrl = relayBaseUrl(),
                idToken = token,
                request = request,
            ).getOrThrow()

            messageDao.upsert(localMessage.copy(delivered = true))
            syncChats(senderId)
        }
    }

    override suspend fun seedWelcomeConversation(uid: String): Result<Unit> = runCatching {
        val chatId = chatIdForUsers(uid, BOT_ID)
        val now = System.currentTimeMillis()
        chatDao.upsert(
            ChatEntity(
                chatId = chatId,
                ownerId = uid,
                peerId = BOT_ID,
                peerName = "Nexora Bot",
                peerPhotoUrl = null,
                lastMessagePreview = "Bienvenido a Nexora",
                lastMessageTimestamp = now,
                lastMessageSenderId = BOT_ID,
                unreadCount = 1,
            )
        )
        val payload = cryptoManager.encrypt("Bienvenido a Nexora")
        messageDao.upsert(
            MessageEntity(
                id = "welcome_$now",
                chatId = chatId,
                senderId = BOT_ID,
                recipientId = uid,
                kind = MessageKind.TEXT.name,
                encryptedPayload = payload.cipherTextBase64,
                iv = payload.ivBase64,
                timestamp = now,
                delivered = true,
                read = false,
            )
        )
    }

    private suspend fun syncChats(uid: String) {
        val token = auth.currentUser?.getIdToken(false)?.await()?.token ?: return
        val json = relayApiClient.fetchChats(relayBaseUrl(), token).getOrNull() ?: return
        val chats = json.optJSONArray("chats") ?: JSONArray()
        for (i in 0 until chats.length()) {
            chats.optJSONObject(i)?.toChatEntity(uid)?.let { chatDao.upsert(it) }
        }
    }

    private suspend fun syncMessages(chatId: String) {
        val token = auth.currentUser?.getIdToken(false)?.await()?.token ?: return
        val since = messageDao.latestTimestamp(chatId).takeIf { it > 0L }
        val json = relayApiClient.fetchMessagesSince(relayBaseUrl(), token, chatId, since).getOrNull() ?: return
        val messages = json.optJSONArray("messages") ?: JSONArray()
        for (i in 0 until messages.length()) {
            messages.optJSONObject(i)?.toMessageEntity(chatId)?.let { messageDao.upsert(it) }
        }
    }

    private fun ChatEntity.toDomain() = Chat(
        chatId = chatId,
        ownerId = ownerId,
        peerId = peerId,
        peerName = peerName,
        peerPhotoUrl = peerPhotoUrl,
        lastMessagePreview = lastMessagePreview,
        lastMessageTimestamp = lastMessageTimestamp,
        lastMessageSenderId = lastMessageSenderId,
        unreadCount = unreadCount,
        isGroup = isGroup,
        groupName = groupName,
        groupPhotoUrl = groupPhotoUrl,
    )

    private fun MessageEntity.toDomain(text: String) = Message(
        id = id,
        chatId = chatId,
        senderId = senderId,
        recipientId = recipientId,
        kind = runCatching { MessageKind.valueOf(kind) }.getOrDefault(MessageKind.TEXT),
        text = text,
        timestamp = timestamp,
        delivered = delivered,
        read = read,
    )

    private fun JSONObject.toChatEntity(uid: String): ChatEntity? {
        val participants = optJSONArray("participants")?.toStringList().orEmpty()
        val peerId = optString("peerId").ifBlank { participants.firstOrNull { it != uid } ?: uid }
        val chatId = optString("chatId").ifBlank { return null }
        return ChatEntity(
            chatId = chatId,
            ownerId = uid,
            peerId = peerId,
            peerName = optString("peerName").ifBlank { "Contacto" },
            peerPhotoUrl = optString("peerPhotoUrl").ifBlank { null },
            lastMessagePreview = optString("lastMessagePreview").ifBlank { "Mensaje cifrado" },
            lastMessageTimestamp = optLong("lastMessageEpochMs", 0L),
            lastMessageSenderId = optString("lastMessageSenderId"),
            unreadCount = optInt("unreadCount", 0),
            isGroup = optBoolean("isGroup", false),
            groupName = optString("groupName").ifBlank { null },
            groupPhotoUrl = optString("groupPhotoUrl").ifBlank { null },
        )
    }

    private fun JSONObject.toMessageEntity(chatId: String): MessageEntity? {
        val encryptedPayload = optString("encryptedPayload").ifBlank { return null }
        val iv = optString("iv").ifBlank { return null }
        return MessageEntity(
            id = optString("messageId").ifBlank { optString("id") },
            chatId = optString("chatId").ifBlank { chatId },
            senderId = optString("senderId"),
            recipientId = optString("recipientId"),
            kind = optString("kind").ifBlank { MessageKind.TEXT.name },
            encryptedPayload = encryptedPayload,
            iv = iv,
            timestamp = optLong("timestamp", 0L),
            delivered = optBoolean("delivered", false),
            read = optBoolean("read", false),
        )
    }

    private fun JSONArray.toStringList(): List<String> = buildList {
        for (i in 0 until length()) {
            val value = optString(i)
            if (value.isNotBlank()) add(value)
        }
    }

    private fun relayBaseUrl(): String {
        val value = BuildConfig.RELAY_BASE_URL.trim()
        require(value.isNotBlank()) { "Define RELAY_BASE_URL en app/build.gradle.kts" }
        require(!value.contains("YOUR-CLOUD-RUN-URL")) {
            "Reemplaza el placeholder RELAY_BASE_URL por la URL real del servidor VPS"
        }
        require(value.startsWith("https://") || value.contains("10.0.2.2") || value.contains("localhost")) {
            "Usa HTTPS en producción para RELAY_BASE_URL"
        }
        return value.trimEnd('/')
    }

    companion object {
        private const val BOT_ID = "nexora_bot"
        private const val CHAT_SYNC_INTERVAL_MS = 5_000L
        private const val MESSAGE_SYNC_INTERVAL_MS = 3_500L
    }
}
