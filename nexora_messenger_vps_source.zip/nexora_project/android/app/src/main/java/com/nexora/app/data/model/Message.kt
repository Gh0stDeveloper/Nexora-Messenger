package com.nexora.app.data.model

enum class MessageKind { TEXT, IMAGE, AUDIO, DOCUMENT }

data class Message(
    val id: String = "",
    val chatId: String = "",
    val senderId: String = "",
    val recipientId: String = "",
    val kind: MessageKind = MessageKind.TEXT,
    val text: String = "",
    val timestamp: Long = 0L,
    val delivered: Boolean = false,
    val read: Boolean = false,
)
