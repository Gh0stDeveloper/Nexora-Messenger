package com.nexora.app.ui.navigation

object Routes {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val PROFILE_SETUP = "profile_setup"
    const val MAIN = "main"
    const val CHATS = "chats"
    const val STORIES = "stories"
    const val SETTINGS = "settings"
    const val CHAT_DETAIL = "chat_detail"
}
