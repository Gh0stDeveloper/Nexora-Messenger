package com.nexora.app.ui.screens.auth

import android.app.Activity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexora.app.ui.state.LoginUiState
import com.nexora.app.ui.viewmodel.LoginViewModel
import com.nexora.app.util.PhoneNumberValidator

@Composable
fun LoginScreen(
    onOtpVerified: () -> Unit,
    viewModel: LoginViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val activity = remember(context) { context as? Activity }
    var phone by remember { mutableStateOf("+52") }
    var code by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }
    val finish by rememberUpdatedState(onOtpVerified)

    LaunchedEffect(state) {
        if (state is LoginUiState.Success) finish()
        if (state is LoginUiState.OtpSent) verificationId = (state as LoginUiState.OtpSent).verificationId
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Nexora", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(8.dp))
        Text("Acceso por número telefónico", style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = phone,
            onValueChange = { phone = it },
            label = { Text("Número en formato E.164") },
            singleLine = true,
        )
        Spacer(Modifier.height(12.dp))
        Button(
            enabled = phone.length >= 8 && PhoneNumberValidator.isValid(phone) && activity != null,
            onClick = { activity?.let { viewModel.requestOtp(it, phone.trim()) } },
        ) {
            Icon(Icons.AutoMirrored.Outlined.Send, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Enviar código")
        }
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = code,
            onValueChange = { code = it.filter(Char::isDigit).take(6) },
            label = { Text("Código OTP") },
            singleLine = true,
        )
        Spacer(Modifier.height(12.dp))
        Button(
            enabled = verificationId != null && code.length == 6,
            onClick = {
                verificationId?.let { viewModel.verifyOtp(it, code) }
            },
        ) {
            Text("Verificar código")
        }
        if (state is LoginUiState.Error) {
            Spacer(Modifier.height(12.dp))
            Text((state as LoginUiState.Error).message, color = MaterialTheme.colorScheme.error)
        }
    }
}
