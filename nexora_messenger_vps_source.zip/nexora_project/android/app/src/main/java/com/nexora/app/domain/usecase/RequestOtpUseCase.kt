package com.nexora.app.domain.usecase

import android.app.Activity
import com.nexora.app.domain.repository.AuthRepository
import javax.inject.Inject

class RequestOtpUseCase @Inject constructor(
    private val authRepository: AuthRepository,
) {
    operator fun invoke(activity: Activity, phone: String) = authRepository.requestOtp(activity, phone)
}
