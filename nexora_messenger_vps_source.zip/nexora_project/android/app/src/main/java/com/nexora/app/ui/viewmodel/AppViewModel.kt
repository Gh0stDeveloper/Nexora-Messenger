package com.nexora.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexora.app.domain.repository.AuthRepository
import com.nexora.app.domain.repository.UserRepository
import com.nexora.app.ui.state.AppUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AppViewModel @Inject constructor(
    authRepository: AuthRepository,
    private val userRepository: UserRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(AppUiState())
    val uiState: StateFlow<AppUiState> = _uiState.asStateFlow()
    private var observeJob: Job? = null

    init {
        viewModelScope.launch {
            authRepository.currentUserId.collect { uid ->
                _uiState.value = AppUiState(currentUserId = uid, profileComplete = false)
                observeJob?.cancel()
                if (uid != null) {
                    observeJob = launch {
                        userRepository.observeUser(uid).collect { user ->
                            _uiState.value = AppUiState(
                                currentUserId = uid,
                                profileComplete = user?.name?.isNotBlank() == true,
                            )
                        }
                    }
                }
            }
        }
    }
}
