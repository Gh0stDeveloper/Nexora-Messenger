package com.nexora.app.data.repository

import com.nexora.app.data.local.dao.UserDao
import com.nexora.app.data.local.entity.UserEntity
import com.nexora.app.data.model.User
import com.nexora.app.domain.repository.UserRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LocalUserRepository @Inject constructor(
    private val userDao: UserDao,
) : UserRepository {
    override fun observeUser(uid: String): Flow<User?> = userDao.observe(uid).map { entity -> entity?.toDomain() }

    override suspend fun upsert(user: User): Result<Unit> = runCatching {
        userDao.upsert(user.toEntity())
    }

    override suspend fun ensureUser(uid: String, phone: String, publicKey: String?): Result<Unit> = runCatching {
        val existing = userDao.get(uid)
        if (existing == null) {
            userDao.upsert(
                UserEntity(
                    uid = uid,
                    phone = phone,
                    name = "",
                    photoUrl = null,
                    status = "Disponible",
                    lastSeen = System.currentTimeMillis(),
                    publicKey = publicKey,
                    updatedAt = System.currentTimeMillis(),
                )
            )
        }
    }

    override suspend fun saveProfile(uid: String, phone: String, name: String, photoUrl: String?, publicKey: String?): Result<Unit> = runCatching {
        userDao.upsert(
            UserEntity(
                uid = uid,
                phone = phone,
                name = name,
                photoUrl = photoUrl,
                status = "Disponible",
                lastSeen = System.currentTimeMillis(),
                publicKey = publicKey,
                updatedAt = System.currentTimeMillis(),
            )
        )
    }

    override suspend fun uploadAvatar(uid: String, localUri: String): Result<String> = Result.success(localUri)

    override suspend fun saveFcmToken(uid: String, token: String): Result<Unit> = Result.success(Unit)

    private fun UserEntity.toDomain() = User(
        uid = uid,
        phone = phone,
        name = name,
        photoUrl = photoUrl,
        status = status,
        lastSeen = lastSeen,
        publicKey = publicKey,
    )

    private fun User.toEntity() = UserEntity(
        uid = uid,
        phone = phone,
        name = name,
        photoUrl = photoUrl,
        status = status,
        lastSeen = lastSeen,
        publicKey = publicKey,
        updatedAt = System.currentTimeMillis(),
    )
}
