package com.nexora.app

import android.app.Application
import com.nexora.app.notification.NexoraNotificationChannels
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class NexoraApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        NexoraNotificationChannels.create(this)
    }
}
