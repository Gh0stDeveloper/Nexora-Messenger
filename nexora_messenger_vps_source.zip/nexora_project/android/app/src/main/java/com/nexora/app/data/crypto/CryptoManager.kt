package com.nexora.app.data.crypto

interface CryptoManager {
    fun encrypt(plainText: String): EncryptedPayload
    fun decrypt(payload: EncryptedPayload): String
}

data class EncryptedPayload(
    val cipherTextBase64: String,
    val ivBase64: String,
)
