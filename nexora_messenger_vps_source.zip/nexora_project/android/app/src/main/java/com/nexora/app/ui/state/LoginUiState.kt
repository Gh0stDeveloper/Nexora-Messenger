package com.nexora.app.ui.state

sealed interface LoginUiState {
    data object Idle : LoginUiState
    data object Loading : LoginUiState
    data class OtpSent(val verificationId: String) : LoginUiState
    data class Success(val uid: String) : LoginUiState
    data class Error(val message: String) : LoginUiState
}
