package com.nexora.app.util

fun chatIdForUsers(first: String, second: String): String {
    val sorted = listOf(first, second).sorted()
    return "${sorted[0]}_${sorted[1]}"
}

fun previewFromPlainText(text: String, max: Int = 64): String {
    val clean = text.trim().replace("
", " ")
    return if (clean.length <= max) clean else clean.take(max - 1) + "…"
}

fun timeLabel(epochMillis: Long): String {
    val minutes = ((System.currentTimeMillis() - epochMillis) / 60000).coerceAtLeast(0)
    return when {
        minutes < 1 -> "ahora"
        minutes < 60 -> "$minutes min"
        minutes < 24 * 60 -> "${minutes / 60} h"
        else -> "${minutes / (24 * 60)} d"
    }
}
