package com.nexora.app.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.content.getSystemService

object NexoraNotificationChannels {
    const val MESSAGES = "messages"

    fun create(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService<NotificationManager>() ?: return
        val channel = NotificationChannel(
            MESSAGES,
            "Mensajes",
            NotificationManager.IMPORTANCE_HIGH,
        ).apply {
            description = "Notificaciones de mensajes cifrados de Nexora"
            enableVibration(true)
        }
        manager.createNotificationChannel(channel)
    }
}
