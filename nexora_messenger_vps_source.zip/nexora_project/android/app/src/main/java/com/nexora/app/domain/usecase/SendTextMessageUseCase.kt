package com.nexora.app.domain.usecase

import com.nexora.app.domain.repository.ChatRepository
import javax.inject.Inject

class SendTextMessageUseCase @Inject constructor(
    private val chatRepository: ChatRepository,
) {
    suspend operator fun invoke(chatId: String, senderId: String, recipientId: String, text: String) =
        chatRepository.sendTextMessage(chatId, senderId, recipientId, text)
}
