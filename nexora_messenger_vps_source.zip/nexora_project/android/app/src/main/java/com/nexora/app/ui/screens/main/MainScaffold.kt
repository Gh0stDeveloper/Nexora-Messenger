package com.nexora.app.ui.screens.main

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Timelapse
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexora.app.ui.viewmodel.AppViewModel
import com.nexora.app.ui.viewmodel.ChatsViewModel
import com.nexora.app.ui.viewmodel.StoriesViewModel

@Composable
fun MainScaffold(
    onOpenChat: (chatId: String, title: String, peerId: String) -> Unit,
    onLogout: () -> Unit,
    appViewModel: AppViewModel = hiltViewModel(),
    chatsViewModel: ChatsViewModel = hiltViewModel(),
    storiesViewModel: StoriesViewModel = hiltViewModel(),
) {
    val appState by appViewModel.uiState.collectAsStateWithLifecycle()
    var selectedTab by remember { mutableIntStateOf(0) }

    LaunchedEffect(appState.currentUserId) {
        appState.currentUserId?.let { uid ->
            chatsViewModel.load(uid)
            storiesViewModel.load()
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Outlined.ChatBubbleOutline, null) },
                    label = { Text("Chats") },
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Outlined.Timelapse, null) },
                    label = { Text("Estados") },
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Outlined.Settings, null) },
                    label = { Text("Ajustes") },
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (selectedTab) {
                0 -> ChatsScreen(onOpenChat = onOpenChat, viewModel = chatsViewModel)
                1 -> StoriesScreen(viewModel = storiesViewModel)
                else -> SettingsScreen(onLogout = onLogout)
            }
        }
    }
}
