package com.nexora.app.ui.screens.auth

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.nexora.app.ui.viewmodel.ProfileSetupViewModel

@Composable
fun ProfileSetupScreen(
    onFinished: () -> Unit,
    viewModel: ProfileSetupViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var localPreview by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            val value = uri?.toString()
            localPreview = value
            if (value != null) viewModel.onPhotoChanged(value)
        }
    )

    Box(modifier = Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text("Crea tu identidad", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    "Tu nombre será visible para tus contactos. La foto es opcional y podrás cambiarla después.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                AvatarPreview(localPreview)

                OutlinedButton(onClick = {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }) {
                    Text(if (localPreview == null) "Elegir foto" else "Cambiar foto")
                }

                OutlinedTextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = state.name,
                    onValueChange = viewModel::onNameChanged,
                    label = { Text("Nombre de usuario") },
                    singleLine = true,
                    supportingText = { Text("Obligatorio. Máximo recomendado: 40 caracteres.") },
                )

                Button(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !state.isSaving && state.name.isNotBlank(),
                    onClick = { viewModel.save(onFinished) },
                ) {
                    Text(if (state.isSaving) "Guardando perfil..." else "Continuar")
                }

                if (state.error != null) {
                    Text(state.error!!, color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
private fun AvatarPreview(localPreview: String?) {
    Box(
        modifier = Modifier
            .size(104.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center,
    ) {
        if (localPreview.isNullOrBlank()) {
            Text("NX", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        } else {
            AsyncImage(
                model = localPreview,
                contentDescription = "Foto de perfil seleccionada",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
    Spacer(Modifier.height(2.dp))
}
