package com.nexora.app.ui.state

import com.nexora.app.data.model.Message

data class ChatDetailUiState(
    val isLoading: Boolean = true,
    val messages: List<Message> = emptyList(),
    val draft: String = "",
    val chatTitle: String = "",
    val peerId: String = "",
    val error: String? = null,
)
