package com.nexora.app.data.repository

import android.app.Activity
import com.nexora.app.data.remote.OtpEvent
import com.nexora.app.data.session.SessionStore
import com.nexora.app.domain.repository.AuthRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.callbackFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LocalAuthRepository @Inject constructor(
    private val sessionStore: SessionStore,
) : AuthRepository {
    override val currentUserId: StateFlow<String?> = sessionStore.currentUserId
    override val currentPhone: StateFlow<String?> = sessionStore.currentPhone
    private val _currentPhone = MutableStateFlow<String?>(null)
    private var verificationCode: String = "123456"
    private var pendingPhone: String? = null

    override fun requestOtp(activity: Activity, phoneE164: String): Flow<OtpEvent> = callbackFlow {
        delay(350)
        pendingPhone = phoneE164
        sessionStore.setCurrentPhone(phoneE164)
        verificationCode = "123456"
        trySend(OtpEvent.CodeSent("verification-${phoneE164.hashCode()}"))
        awaitClose { }
    }

    override suspend fun verifyOtp(verificationId: String, code: String): Result<String> {
        delay(250)
        return if (code == verificationCode && pendingPhone != null) {
            val uid = "uid_${pendingPhone.hashCode().toUInt().toString(16)}"
            sessionStore.setCurrentUserId(uid)
            Result.success(uid)
        } else {
            Result.failure(IllegalArgumentException("OTP inválido o expirado"))
        }
    }

    override suspend fun saveProfile(uid: String, name: String, photoUrl: String?): Result<Unit> {
        return Result.success(Unit)
    }

    override suspend fun signOut() {
        pendingPhone = null
        _currentPhone.value = null
        sessionStore.clear()
    }
}
