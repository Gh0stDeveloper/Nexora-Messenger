package com.nexora.app.domain.usecase

import com.nexora.app.domain.repository.AuthRepository
import com.nexora.app.domain.repository.UserRepository
import javax.inject.Inject

class SaveProfileUseCase @Inject constructor(
    private val authRepository: AuthRepository,
    private val userRepository: UserRepository,
) {
    suspend operator fun invoke(uid: String, phone: String, name: String, photoUrl: String?) = runCatching {
        val remotePhotoUrl = photoUrl
            ?.trim()
            ?.takeIf { it.isNotBlank() }
            ?.let { value ->
                if (value.startsWith("content://") || value.startsWith("file://")) {
                    userRepository.uploadAvatar(uid, value).getOrThrow()
                } else value
            }
        authRepository.saveProfile(uid, name, remotePhotoUrl).getOrThrow()
    }
}
