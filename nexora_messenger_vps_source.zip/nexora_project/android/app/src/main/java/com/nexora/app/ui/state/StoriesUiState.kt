package com.nexora.app.ui.state

import com.nexora.app.data.model.Story

data class StoriesUiState(
    val isLoading: Boolean = true,
    val stories: List<Story> = emptyList(),
)
