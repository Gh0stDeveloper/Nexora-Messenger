package com.nexora.app.domain.usecase

import com.nexora.app.domain.repository.StoryRepository
import javax.inject.Inject

class ObserveStoriesUseCase @Inject constructor(
    private val storyRepository: StoryRepository,
) {
    operator fun invoke() = storyRepository.observeStories()
}
