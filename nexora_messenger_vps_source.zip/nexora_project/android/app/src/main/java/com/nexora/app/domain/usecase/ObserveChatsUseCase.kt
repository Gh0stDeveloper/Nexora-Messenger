package com.nexora.app.domain.usecase

import com.nexora.app.domain.repository.ChatRepository
import javax.inject.Inject

class ObserveChatsUseCase @Inject constructor(
    private val chatRepository: ChatRepository,
) {
    operator fun invoke(uid: String) = chatRepository.observeChats(uid)
}
