package com.nexora.app.data.repository

import com.nexora.app.data.crypto.CryptoManager
import com.nexora.app.data.crypto.EncryptedPayload
import com.nexora.app.data.local.dao.ChatDao
import com.nexora.app.data.local.dao.MessageDao
import com.nexora.app.data.local.entity.ChatEntity
import com.nexora.app.data.local.entity.MessageEntity
import com.nexora.app.data.model.Chat
import com.nexora.app.data.model.Message
import com.nexora.app.data.model.MessageKind
import com.nexora.app.domain.repository.ChatRepository
import com.nexora.app.util.chatIdForUsers
import com.nexora.app.util.previewFromPlainText
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LocalChatRepository @Inject constructor(
    private val chatDao: ChatDao,
    private val messageDao: MessageDao,
    private val cryptoManager: CryptoManager,
) : ChatRepository {
    override fun observeChats(uid: String): Flow<List<Chat>> = chatDao.observeForUser(uid).map { list ->
        list.map { it.toDomain() }
    }

    override fun observeMessages(chatId: String): Flow<List<Message>> = messageDao.observeForChat(chatId).map { list ->
        list.map { entity ->
            val text = runCatching {
                cryptoManager.decrypt(
                    EncryptedPayload(
                        cipherTextBase64 = entity.encryptedPayload,
                        ivBase64 = entity.iv,
                    )
                )
            }.getOrDefault("[Mensaje cifrado]")
            entity.toDomain(text)
        }
    }

    override suspend fun sendTextMessage(chatId: String, senderId: String, recipientId: String, plainText: String): Result<Unit> = runCatching {
        val encrypted = cryptoManager.encrypt(plainText)
        val now = System.currentTimeMillis()
        messageDao.upsert(
            MessageEntity(
                id = "msg_$now",
                chatId = chatId,
                senderId = senderId,
                recipientId = recipientId,
                kind = MessageKind.TEXT.name,
                encryptedPayload = encrypted.cipherTextBase64,
                iv = encrypted.ivBase64,
                timestamp = now,
                delivered = true,
                read = false,
            )
        )
        val existing = chatDao.get(chatId)
        val chat = existing ?: ChatEntity(
            chatId = chatId,
            ownerId = senderId,
            peerId = recipientId,
            peerName = "Contacto",
            peerPhotoUrl = null,
            lastMessagePreview = previewFromPlainText(plainText),
            lastMessageTimestamp = now,
            lastMessageSenderId = senderId,
            unreadCount = 0,
        )
        chatDao.upsert(
            chat.copy(
                lastMessagePreview = previewFromPlainText(plainText),
                lastMessageTimestamp = now,
                lastMessageSenderId = senderId,
            )
        )
    }

    override suspend fun seedWelcomeConversation(uid: String): Result<Unit> = runCatching {
        val chatId = chatIdForUsers(uid, "nexora_bot")
        val now = System.currentTimeMillis()
        chatDao.upsert(
            ChatEntity(
                chatId = chatId,
                ownerId = uid,
                peerId = "nexora_bot",
                peerName = "Nexora Bot",
                peerPhotoUrl = null,
                lastMessagePreview = "Bienvenido a Nexora",
                lastMessageTimestamp = now,
                lastMessageSenderId = "nexora_bot",
                unreadCount = 1,
            )
        )
        val payload = cryptoManager.encrypt("Bienvenido a Nexora")
        messageDao.upsert(
            MessageEntity(
                id = "welcome_$now",
                chatId = chatId,
                senderId = "nexora_bot",
                recipientId = uid,
                kind = MessageKind.TEXT.name,
                encryptedPayload = payload.cipherTextBase64,
                iv = payload.ivBase64,
                timestamp = now,
                delivered = true,
                read = false,
            )
        )
    }

    private fun ChatEntity.toDomain() = Chat(
        chatId = chatId,
        ownerId = ownerId,
        peerId = peerId,
        peerName = peerName,
        peerPhotoUrl = peerPhotoUrl,
        lastMessagePreview = lastMessagePreview,
        lastMessageTimestamp = lastMessageTimestamp,
        lastMessageSenderId = lastMessageSenderId,
        unreadCount = unreadCount,
        isGroup = isGroup,
        groupName = groupName,
        groupPhotoUrl = groupPhotoUrl,
    )

    private fun MessageEntity.toDomain(text: String) = Message(
        id = id,
        chatId = chatId,
        senderId = senderId,
        recipientId = recipientId,
        kind = runCatching { MessageKind.valueOf(kind) }.getOrDefault(MessageKind.TEXT),
        text = text,
        timestamp = timestamp,
        delivered = delivered,
        read = read,
    )
}
