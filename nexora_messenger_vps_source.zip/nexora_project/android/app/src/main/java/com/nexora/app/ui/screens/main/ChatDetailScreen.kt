package com.nexora.app.ui.screens.main

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexora.app.ui.components.MessageBubble
import com.nexora.app.ui.viewmodel.AppViewModel
import com.nexora.app.ui.viewmodel.ChatDetailViewModel

@Composable
fun ChatDetailScreen(
    chatId: String,
    title: String,
    peerId: String,
    onBack: () -> Unit,
    appViewModel: AppViewModel = hiltViewModel(),
    viewModel: ChatDetailViewModel = hiltViewModel(),
) {
    val appState by appViewModel.uiState.collectAsStateWithLifecycle()
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(chatId) {
        viewModel.load(chatId, peerId, title)
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(title.ifBlank { "Chat" }, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        if (state.isLoading) {
            CircularProgressIndicator()
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(state.messages, key = { it.id }) { message ->
                    val mine = message.senderId == appState.currentUserId
                    MessageBubble(text = message.text, mine = mine)
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                modifier = Modifier.fillMaxWidth(),
                value = state.draft,
                onValueChange = viewModel::onDraftChanged,
                label = { Text("Escribe un mensaje") },
            )
            Spacer(Modifier.height(8.dp))
            Row {
                Button(
                    onClick = {
                        val sender = appState.currentUserId.orEmpty()
                        viewModel.send(chatId, sender, peerId)
                    },
                    enabled = appState.currentUserId != null,
                ) {
                    Icon(Icons.AutoMirrored.Outlined.Send, null)
                    Text("Enviar")
                }
            }
        }
    }
}
