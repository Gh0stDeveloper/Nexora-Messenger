package com.nexora.app.domain.repository

import com.nexora.app.data.model.Chat
import com.nexora.app.data.model.Message
import kotlinx.coroutines.flow.Flow

interface ChatRepository {
    fun observeChats(uid: String): Flow<List<Chat>>
    fun observeMessages(chatId: String): Flow<List<Message>>
    suspend fun sendTextMessage(chatId: String, senderId: String, recipientId: String, plainText: String): Result<Unit>
    suspend fun seedWelcomeConversation(uid: String): Result<Unit>
}
