package com.nexora.app.ui.state

import com.nexora.app.data.model.Chat

data class ChatsUiState(
    val isLoading: Boolean = true,
    val chats: List<Chat> = emptyList(),
    val error: String? = null,
)
