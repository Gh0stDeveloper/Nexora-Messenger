package com.nexora.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkScheme = darkColorScheme(
    primary = NexoraPrimary,
    secondary = NexoraSecondary,
    background = NexoraBackground,
    surface = NexoraSurface,
)

@Composable
fun NexoraTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkScheme, content = content)
}
