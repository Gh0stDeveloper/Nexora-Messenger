package com.nexora.app.domain.usecase

import com.nexora.app.domain.repository.AuthRepository
import javax.inject.Inject

class VerifyOtpUseCase @Inject constructor(
    private val authRepository: AuthRepository,
) {
    suspend operator fun invoke(verificationId: String, code: String) = authRepository.verifyOtp(verificationId, code)
}
