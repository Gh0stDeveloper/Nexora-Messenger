package com.nexora.app.domain.repository

import com.nexora.app.data.model.User
import kotlinx.coroutines.flow.Flow

interface UserRepository {
    fun observeUser(uid: String): Flow<User?>
    suspend fun upsert(user: User): Result<Unit>
    suspend fun ensureUser(uid: String, phone: String, publicKey: String?): Result<Unit>
    suspend fun saveProfile(uid: String, phone: String, name: String, photoUrl: String?, publicKey: String?): Result<Unit>
    suspend fun uploadAvatar(uid: String, localUri: String): Result<String>
    suspend fun saveFcmToken(uid: String, token: String): Result<Unit>
}
