## Nexora proguard rules

# Firebase / Hilt safe defaults
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**
-keep class dagger.hilt.** { *; }
-dontwarn dagger.hilt.**
