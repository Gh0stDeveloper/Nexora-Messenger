# Nexora Messenger

**Nexora Messenger** es una aplicación Android nativa de mensajería privada con registro por número telefónico, perfil de usuario, relay cifrado en VPS propio y almacenamiento local en el dispositivo.

El objetivo del proyecto es construir una alternativa moderna y profesional de mensajería: interfaz limpia, privacidad real, backend controlado por el dueño del proyecto y una arquitectura preparada para crecer hacia grupos, multimedia, estados, llamadas y multi-dispositivo.

---

## Estado actual

Esta entrega deja el proyecto listo como **monorepo Android + servidor VPS**.

Incluye:

- App Android nativa en **Kotlin + Jetpack Compose**.
- Registro/login con **Firebase Auth por teléfono**.
- Sincronización de **FCM token** para notificaciones.
- Perfil con nombre obligatorio y avatar opcional.
- Avatares guardados en el **VPS propio**, no en Firebase Storage.
- Backend propio en **Node.js + Express**.
- Base de datos **PostgreSQL** para usuarios, chats y mensajes cifrados.
- Relay de mensajes que guarda solo `encryptedPayload + iv`.
- Docker Compose para levantar servidor y PostgreSQL.
- Nginx + Certbot para HTTPS.
- GitHub Actions para validar Android, backend, Docker y despliegue VPS.

---

## Arquitectura general

```text
Nexora Android
 ├─ Firebase Auth
 │   └─ OTP por número telefónico
 ├─ Firebase Cloud Messaging
 │   └─ notificaciones push
 ├─ Room
 │   └─ caché local de chats/mensajes
 ├─ Android Keystore
 │   └─ clave local del dispositivo
 └─ HTTPS
     └─ VPS Relay API

VPS Nexora
 ├─ Nginx
 │   └─ reverse proxy + TLS
 ├─ Node.js / Express
 │   ├─ verificación de Firebase ID Token
 │   ├─ relay de mensajes cifrados
 │   ├─ subida de avatar de perfil
 │   └─ envío de push FCM
 ├─ PostgreSQL
 │   ├─ users
 │   ├─ chats
 │   └─ messages
 └─ Docker Compose
```

---

## Qué se guarda y dónde

### En el teléfono

- Sesión local.
- Claves locales del dispositivo.
- Caché de usuario.
- Mensajes sincronizados.
- Estado local de chats.

### En el VPS

- UID del usuario.
- Teléfono asociado por Firebase Auth.
- Nombre de perfil.
- URL del avatar.
- Clave pública E2EE.
- Token FCM.
- Chats.
- Mensajes cifrados.
- Estados de entrega/lectura.

### En Firebase

- OTP / autenticación telefónica.
- Firebase ID Token.
- FCM.

Firebase **no guarda los avatares** ni el contenido de mensajes en esta versión VPS.

---

## Seguridad del relay

El servidor no recibe mensajes en texto plano.

Cada mensaje viaja como:

```json
{
  "chatId": "uid1_uid2",
  "messageId": "uuid",
  "senderId": "uid1",
  "recipientId": "uid2",
  "kind": "TEXT",
  "encryptedPayload": "base64",
  "iv": "base64",
  "timestamp": 1760000000000
}
```

El backend:

- verifica `Authorization: Bearer FIREBASE_ID_TOKEN`;
- comprueba que `senderId` sea el usuario autenticado;
- valida `chatId` canónico;
- bloquea previews enviados por cliente;
- guarda siempre `Mensaje cifrado` como preview;
- rechaza duplicados por `messageId`;
- solo permite ACK de entrega/lectura al destinatario real.

---

## Estructura del repositorio

```text
.
├── android/
│   ├── app/
│   ├── build.gradle.kts
│   ├── settings.gradle.kts
│   └── CONFIGURATION.md
├── backend/
│   ├── vps-api/
│   │   ├── server.js
│   │   ├── Dockerfile
│   │   └── package.json
│   ├── vps/
│   │   ├── docker-compose.yml
│   │   ├── nginx/
│   │   ├── scripts/
│   │   ├── secrets/
│   │   └── systemd/
│   ├── functions/
│   ├── firestore.rules
│   ├── storage.rules
│   └── VPS_DEPLOYMENT.md
└── .github/workflows/
    ├── ci.yml
    ├── android-build.yml
    ├── deploy-vps.yml
    ├── deploy-cloud-run.yml
    └── deploy-firebase-functions.yml
```

---

## Endpoints principales del VPS

```text
GET  /health
GET  /ready
GET  /v1/relay/version
POST /v1/relay/users/me/bootstrap
POST /v1/relay/users/me/avatar
POST /v1/relay/users/me/fcm-token
GET  /v1/relay/users/:uid/public
POST /v1/relay/messages
GET  /v1/relay/chats
GET  /v1/relay/chats/:chatId/messages
POST /v1/relay/ack
```

Los endpoints `/v1/relay/*` requieren:

```text
Authorization: Bearer FIREBASE_ID_TOKEN
```

---

## Configuración Android

### 1. Firebase

Crea un proyecto Firebase y agrega una app Android con:

```text
com.nexora.app
```

Descarga el archivo real:

```text
google-services.json
```

Colócalo en:

```text
android/app/google-services.json
```

### 2. URL del VPS

Compila apuntando a tu servidor:

```bash
cd android
gradle :app:assembleDebug -PNEXORA_RELAY_BASE_URL=https://api.tu-dominio.com
```

También puedes usar variable de entorno:

```bash
export NEXORA_RELAY_BASE_URL=https://api.tu-dominio.com
cd android && gradle :app:assembleDebug
```

---

## Configuración del VPS

### 1. Instalar dependencias del servidor

```bash
sudo bash backend/vps/scripts/install-vps.sh
```

### 2. Subir proyecto

```bash
sudo mkdir -p /opt/nexora
sudo chown -R $USER:$USER /opt/nexora
rsync -az ./ /opt/nexora/
```

### 3. Configurar `.env`

```bash
cd /opt/nexora/backend/vps
cp .env.example .env
nano .env
```

Valores mínimos:

```env
DOMAIN=api.tu-dominio.com
POSTGRES_PASSWORD=pon_una_password_larga
DATABASE_URL=postgresql://nexora:pon_una_password_larga@postgres:5432/nexora
FIREBASE_PROJECT_ID=tu-proyecto-firebase
APP_PUBLIC_BASE_URL=https://api.tu-dominio.com
UPLOAD_DIR=/app/uploads
MAX_AVATAR_BYTES=2097152
```

### 4. Service account Firebase Admin

Coloca tu service account en:

```text
backend/vps/secrets/firebase-service-account.json
```

No subas ese archivo a GitHub.

### 5. Levantar servidor

```bash
cd /opt/nexora/backend/vps
./scripts/deploy.sh
```

Verificar:

```bash
curl http://127.0.0.1:8080/health
curl http://127.0.0.1:8080/ready
```

---

## Nginx + HTTPS

```bash
sudo cp backend/vps/nginx/nexora-api.conf /etc/nginx/sites-available/nexora-api.conf
sudo sed -i 's/api.tu-dominio.com/api.TU-DOMINIO.com/g' /etc/nginx/sites-available/nexora-api.conf
sudo ln -sf /etc/nginx/sites-available/nexora-api.conf /etc/nginx/sites-enabled/nexora-api.conf
sudo nginx -t
sudo systemctl reload nginx
sudo certbot --nginx -d api.TU-DOMINIO.com
```

---

## GitHub Actions

### CI general

El workflow principal valida:

- compilación Android debug;
- sintaxis del API VPS;
- instalación de dependencias Node;
- build Docker del API VPS;
- build de Firebase Functions.

Archivo:

```text
.github/workflows/ci.yml
```

### Secrets recomendados

```text
GOOGLE_SERVICES_JSON
NEXORA_RELAY_BASE_URL
VPS_HOST
VPS_USER
VPS_SSH_KEY
VPS_APP_DIR
```

### Despliegue al VPS

El workflow:

```text
.github/workflows/deploy-vps.yml
```

hace:

- checkout del repo;
- conexión SSH;
- subida de `backend/vps-api` y `backend/vps`;
- `docker compose up -d --build` en el VPS.

---

## Comandos útiles

### Android

```bash
cd android
gradle :app:assembleDebug --stacktrace
```

### API VPS

```bash
cd backend/vps-api
npm install
npm run check
npm start
```

### Docker VPS local

```bash
cd backend/vps
docker compose up -d --build
docker compose logs -f api
```

### Backup PostgreSQL

```bash
cd backend/vps
./scripts/backup-postgres.sh
```

### Restaurar backup

```bash
./scripts/restore-postgres.sh backups/nexora-YYYYmmdd-HHMMSS.sql.gz
```

---

## Roadmap inmediato

- Integrar sesiones E2EE por destinatario/dispositivo.
- Agregar contactos por agenda telefónica con hashing.
- Crear grupos con roles.
- Añadir estados efímeros.
- Añadir subida cifrada de imágenes/documentos al VPS.
- Crear release firmado por GitHub Actions.
- Añadir página web pública de descarga.

---

## Créditos

Proyecto desarrollado para el ecosistema **Nexora** por **Ghost Developer**.

Nexora Messenger está pensado para crecer como una app de mensajería real, privada y controlada desde infraestructura propia.
