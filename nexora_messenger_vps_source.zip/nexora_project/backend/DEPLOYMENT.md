# Nexora Backend — Despliegue

## Ruta recomendada actual: VPS propio

Usa:

```text
backend/VPS_DEPLOYMENT.md
backend/vps/README.md
backend/vps-api/README.md
```

La arquitectura VPS usa:

- Node.js/Express para el relay cifrado.
- PostgreSQL para cola e historial cifrado.
- Firebase Admin para verificar tokens y enviar FCM.
- Nginx + Certbot para HTTPS.
- Docker Compose para levantar servicios.

## Compilar Android contra el VPS

```bash
cd android
./gradlew :app:assembleDebug -PNEXORA_RELAY_BASE_URL=https://api.TU-DOMINIO.com
```

## Alternativa heredada: Google Cloud Run

El directorio `backend/cloud-run-api` se conserva como alternativa si después quieres volver a Cloud Run. Para el alcance actual de servidor propio, no es necesario usarlo.
