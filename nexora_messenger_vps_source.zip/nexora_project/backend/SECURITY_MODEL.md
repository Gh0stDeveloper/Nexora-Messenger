# Nexora — Modelo de seguridad VPS

## Principios

- El cliente cifra antes de enviar.
- El VPS nunca recibe texto plano del mensaje.
- El VPS verifica `Authorization: Bearer FIREBASE_ID_TOKEN` usando Firebase Admin.
- El VPS solo almacena `encryptedPayload`, `iv`, participantes, timestamps y estados de entrega.
- Las notificaciones FCM son genéricas: no incluyen contenido real.

## Componentes

### Android

- Autenticación con Firebase Auth por teléfono.
- Token de sesión usado contra el VPS.
- Persistencia local con Room.
- Mensajes descifrados solo localmente.

### VPS Relay API

- Node.js/Express.
- PostgreSQL.
- Rate limiting por usuario/ruta.
- Validación de UID, chatId, timestamp, tipo, IV y ciphertext.
- Prevención de duplicados por `(chat_id, message_id)`.
- Purga periódica de mensajes expirados.

### Nginx

- HTTPS público.
- Reverse proxy hacia `127.0.0.1:8080`.
- El API no queda expuesto directamente a internet sin TLS.

## Datos almacenados en PostgreSQL

```text
users
chats
messages
```

`messages.encrypted_payload` contiene solo ciphertext. El campo visible para lista de chats es siempre `Mensaje cifrado`.

## Riesgo pendiente

La estructura está lista para E2EE real por sesión/dispositivo, pero el `CryptoManager` inicial aún debe evolucionar a libsignal/Signal Protocol o equivalente auditado antes de producción pública.
