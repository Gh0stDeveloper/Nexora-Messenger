# Nexora en VPS

Esta carpeta deja listo el despliegue propio del servidor de Nexora usando:

- Node.js/Express para el relay cifrado.
- PostgreSQL para cola e historial cifrado.
- Firebase Admin solo para verificar ID Tokens de Firebase Auth y enviar FCM.
- Nginx como reverse proxy HTTPS.
- Docker Compose para levantar servicios.

## Flujo recomendado

```bash
sudo bash backend/vps/scripts/install-vps.sh
sudo mkdir -p /opt/nexora
sudo cp -r . /opt/nexora
cd /opt/nexora/backend/vps
cp .env.example .env
nano .env
mkdir -p secrets
# Copia tu service account aquí:
# backend/vps/secrets/firebase-service-account.json
./scripts/deploy.sh
```

## Nginx + SSL

```bash
sudo cp nginx/nexora-api.conf /etc/nginx/sites-available/nexora-api.conf
sudo sed -i 's/api.tu-dominio.com/api.TU-DOMINIO.com/g' /etc/nginx/sites-available/nexora-api.conf
sudo ln -s /etc/nginx/sites-available/nexora-api.conf /etc/nginx/sites-enabled/nexora-api.conf
sudo nginx -t
sudo systemctl reload nginx
sudo certbot --nginx -d api.TU-DOMINIO.com
```

## Android

Compila apuntando al VPS:

```bash
cd android
./gradlew :app:assembleDebug -PNEXORA_RELAY_BASE_URL=https://api.TU-DOMINIO.com
```

En GitHub Actions, configura el secret `NEXORA_RELAY_BASE_URL` con esa misma URL.
