#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p backups
STAMP="$(date +%Y%m%d-%H%M%S)"
docker compose exec -T postgres pg_dump -U "${POSTGRES_USER:-nexora}" "${POSTGRES_DB:-nexora}" | gzip > "backups/nexora-$STAMP.sql.gz"
echo "Backup creado: backups/nexora-$STAMP.sql.gz"
