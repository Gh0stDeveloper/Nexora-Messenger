#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

if [[ ! -f .env ]]; then
  echo "Falta backend/vps/.env. Copia .env.example y configúralo."
  exit 1
fi
if [[ ! -f secrets/firebase-service-account.json ]]; then
  echo "Falta backend/vps/secrets/firebase-service-account.json"
  exit 1
fi

docker compose up -d --build
sleep 2
docker compose ps
curl -fsS http://127.0.0.1:8080/health || true
