#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then
  echo "Uso: $0 backups/nexora-YYYYmmdd-HHMMSS.sql.gz"
  exit 1
fi
cd "$(dirname "$0")/.."
gunzip -c "$1" | docker compose exec -T postgres psql -U "${POSTGRES_USER:-nexora}" "${POSTGRES_DB:-nexora}"
