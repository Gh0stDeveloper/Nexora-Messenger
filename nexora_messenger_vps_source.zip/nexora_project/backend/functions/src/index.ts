import * as admin from 'firebase-admin';
import * as functions from 'firebase-functions';

admin.initializeApp();

const db = admin.firestore();
const DEFAULT_REGION = 'us-central1';
const BATCH_LIMIT = 450;

function publicProfileFromUser(uid: string, data: FirebaseFirestore.DocumentData | undefined) {
  return {
    uid,
    name: typeof data?.name === 'string' ? data.name : '',
    photoUrl: typeof data?.photoUrl === 'string' ? data.photoUrl : null,
    status: typeof data?.status === 'string' ? data.status : 'Disponible',
    publicKey: typeof data?.publicKey === 'string' ? data.publicKey : null,
    profileCompleted: Boolean(data?.profileCompleted),
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  };
}

async function deleteDocsInChunks(refs: FirebaseFirestore.DocumentReference[]) {
  for (let i = 0; i < refs.length; i += BATCH_LIMIT) {
    const batch = db.batch();
    refs.slice(i, i + BATCH_LIMIT).forEach((ref) => batch.delete(ref));
    await batch.commit();
  }
}

export const createUserProfile = functions
  .region(DEFAULT_REGION)
  .auth.user()
  .onCreate(async (user) => {
    const profile = {
      uid: user.uid,
      phone: user.phoneNumber ?? '',
      name: user.displayName ?? '',
      photoUrl: user.photoURL ?? null,
      status: 'Disponible',
      lastSeen: admin.firestore.FieldValue.serverTimestamp(),
      publicKey: null,
      profileCompleted: false,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    };

    await db.collection('users').doc(user.uid).set(profile, { merge: true });
    await db.collection('publicProfiles').doc(user.uid).set(publicProfileFromUser(user.uid, profile), { merge: true });
    return null;
  });

export const mirrorPublicProfile = functions
  .region(DEFAULT_REGION)
  .firestore.document('users/{uid}')
  .onWrite(async (change, context) => {
    const uid = context.params.uid;
    if (!change.after.exists) {
      await db.collection('publicProfiles').doc(uid).delete();
      return null;
    }
    await db.collection('publicProfiles').doc(uid).set(publicProfileFromUser(uid, change.after.data()), { merge: true });
    return null;
  });

export const deleteAuthProfile = functions
  .region(DEFAULT_REGION)
  .auth.user()
  .onDelete(async (user) => {
    const refs = [
      db.collection('users').doc(user.uid),
      db.collection('publicProfiles').doc(user.uid),
      db.collection('fcmTokens').doc(user.uid),
    ];
    await deleteDocsInChunks(refs);
    return null;
  });

export const sendMessageNotification = functions
  .region(DEFAULT_REGION)
  .firestore.document('chats/{chatId}/messages/{msgId}')
  .onCreate(async (snap, context) => {
    const message = snap.data() as {
      senderId: string;
      recipientId?: string;
      kind: string;
    };

    const chatDoc = await db.collection('chats').doc(context.params.chatId).get();
    const chat = chatDoc.data() as { participants?: string[] } | undefined;
    const receiverId = message.recipientId ?? chat?.participants?.find((uid) => uid !== message.senderId);
    if (!receiverId || receiverId === message.senderId) return null;

    const tokenDoc = await db.collection('fcmTokens').doc(receiverId).get();
    const token = tokenDoc.data()?.token as string | undefined;
    if (!token) return null;

    try {
      return await admin.messaging().send({
        token,
        notification: {
          title: 'Nexora',
          body: 'Tienes un mensaje cifrado nuevo.',
        },
        android: {
          priority: 'high',
          notification: {
            channelId: 'messages',
            tag: context.params.chatId,
          },
        },
        data: {
          chatId: context.params.chatId,
          messageId: context.params.msgId,
          kind: message.kind,
          encrypted: 'true',
        },
      });
    } catch (error: unknown) {
      const code = (error as { code?: string }).code;
      if (code === 'messaging/registration-token-not-registered' || code === 'messaging/invalid-registration-token') {
        await db.collection('fcmTokens').doc(receiverId).delete();
      }
      functions.logger.error('sendMessageNotification failed', { code, receiverId, chatId: context.params.chatId });
      return null;
    }
  });

export const purgeExpiredStories = functions
  .region(DEFAULT_REGION)
  .pubsub.schedule('every 60 minutes')
  .onRun(async () => {
    const now = admin.firestore.Timestamp.now();
    const snapshot = await db.collectionGroup('items').where('expiresAt', '<=', now).limit(BATCH_LIMIT).get();
    await deleteDocsInChunks(snapshot.docs.map((doc) => doc.ref));
    functions.logger.info('Expired stories purged', { count: snapshot.size });
    return null;
  });

export const purgeExpiredRelayMessages = functions
  .region(DEFAULT_REGION)
  .pubsub.schedule('every 60 minutes')
  .onRun(async () => {
    const now = admin.firestore.Timestamp.now();
    const snapshot = await db.collectionGroup('messages').where('expiresAt', '<=', now).limit(BATCH_LIMIT).get();
    await deleteDocsInChunks(snapshot.docs.map((doc) => doc.ref));
    functions.logger.info('Expired relay messages purged', { count: snapshot.size });
    return null;
  });
