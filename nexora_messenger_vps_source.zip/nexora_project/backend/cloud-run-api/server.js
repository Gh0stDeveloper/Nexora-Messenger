'use strict';

const crypto = require('node:crypto');
const express = require('express');
const admin = require('firebase-admin');

admin.initializeApp();

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', true);
app.use(express.json({ limit: process.env.JSON_LIMIT || '768kb' }));

const db = admin.firestore();
const APP_NAME = 'Nexora';
const SERVICE_NAME = 'nexora-relay-api';
const PROTOCOL_VERSION = 'nexora-e2ee-v1';
const MAX_CIPHERTEXT_BYTES = Number(process.env.MAX_CIPHERTEXT_BYTES || 512 * 1024);
const MAX_MESSAGES_LIMIT = Number(process.env.MAX_MESSAGES_LIMIT || 300);
const ALLOWED_KINDS = new Set(['TEXT', 'IMAGE', 'AUDIO', 'VIDEO', 'DOCUMENT']);
const rateBuckets = new Map();

function nowMs() {
  return Date.now();
}

function requestId() {
  return crypto.randomUUID();
}

function log(level, message, data = {}) {
  const payload = { level, message, service: SERVICE_NAME, ...data };
  const line = JSON.stringify(payload);
  if (level === 'error') console.error(line);
  else if (level === 'warn') console.warn(line);
  else console.log(line);
}

function canonicalChatId(a, b) {
  return [String(a), String(b)].sort().join('_');
}

function sanitizeString(value, maxLength) {
  return String(value || '').trim().slice(0, maxLength);
}

function isLikelyBase64(value) {
  if (typeof value !== 'string' || value.length < 8) return false;
  if (value.length > MAX_CIPHERTEXT_BYTES * 2) return false;
  return /^[A-Za-z0-9+/=_-]+$/.test(value);
}

function isValidUid(value) {
  return typeof value === 'string' && value.length >= 8 && value.length <= 128 && /^[A-Za-z0-9:_-]+$/.test(value);
}

function problem(res, status, code, details = undefined) {
  return res.status(status).json({ ok: false, error: code, details });
}

function corsMiddleware(req, res, next) {
  const allowedOrigins = (process.env.CORS_ORIGINS || '')
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean);
  const origin = req.headers.origin;

  if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
    if (origin) res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type, X-Request-Id');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  }

  if (req.method === 'OPTIONS') return res.status(204).end();
  next();
}

function securityHeaders(_req, res, next) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
}

function rateLimit({ windowMs, max }) {
  return (req, res, next) => {
    const id = req.nexoraAuth?.uid || req.ip || 'anonymous';
    const key = `${req.method}:${req.path}:${id}`;
    const current = rateBuckets.get(key) || { count: 0, resetAt: nowMs() + windowMs };
    if (nowMs() > current.resetAt) {
      current.count = 0;
      current.resetAt = nowMs() + windowMs;
    }
    current.count += 1;
    rateBuckets.set(key, current);
    res.setHeader('X-RateLimit-Limit', String(max));
    res.setHeader('X-RateLimit-Remaining', String(Math.max(0, max - current.count)));
    res.setHeader('X-RateLimit-Reset', String(Math.floor(current.resetAt / 1000)));
    if (current.count > max) return problem(res, 429, 'rate_limited');
    next();
  };
}

setInterval(() => {
  const now = nowMs();
  for (const [key, bucket] of rateBuckets.entries()) {
    if (now > bucket.resetAt + 60_000) rateBuckets.delete(key);
  }
}, 60_000).unref();

async function authRequired(req, res, next) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');
  if (scheme !== 'Bearer' || !token) {
    return problem(res, 401, 'missing_bearer_token');
  }

  try {
    req.nexoraAuth = await admin.auth().verifyIdToken(token, true);
    next();
  } catch (error) {
    log('warn', 'verifyIdToken failed', { requestId: req.id, error: error.message });
    problem(res, 401, 'invalid_token');
  }
}

async function assertUserExists(uid) {
  const userDoc = await db.collection('users').doc(uid).get();
  return userDoc.exists;
}

async function upsertPublicProfile(uid, payload) {
  const publicProfile = {
    uid,
    name: payload.name || '',
    photoUrl: payload.photoUrl || null,
    status: payload.status || 'Disponible',
    publicKey: payload.publicKey || null,
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  };
  await db.collection('publicProfiles').doc(uid).set(publicProfile, { merge: true });
}

function normalizeRelayPayload(body, authUid) {
  const senderId = sanitizeString(body.senderId, 128);
  const recipientId = sanitizeString(body.recipientId, 128);
  const kind = sanitizeString(body.kind || 'TEXT', 24).toUpperCase();
  const encryptedPayload = String(body.encryptedPayload || '');
  const iv = String(body.iv || '');
  const requestedChatId = sanitizeString(body.chatId, 260);
  const messageId = sanitizeString(body.messageId || `msg_${nowMs()}_${crypto.randomUUID().slice(0, 8)}`, 128);
  const protocolVersion = sanitizeString(body.protocolVersion || PROTOCOL_VERSION, 64);
  const timestamp = Number(body.timestamp || nowMs());
  const expiresAtEpochMs = body.expiresAtEpochMs == null ? null : Number(body.expiresAtEpochMs);

  if (!isValidUid(senderId) || !isValidUid(recipientId)) throw new Error('invalid_participants');
  if (senderId === recipientId) throw new Error('same_sender_recipient');
  if (authUid !== senderId) throw new Error('sender_mismatch');
  if (!ALLOWED_KINDS.has(kind)) throw new Error('invalid_kind');
  if (!isLikelyBase64(encryptedPayload)) throw new Error('invalid_encrypted_payload');
  if (!isLikelyBase64(iv) || iv.length > 256) throw new Error('invalid_iv');
  if (!Number.isFinite(timestamp) || Math.abs(nowMs() - timestamp) > 1000 * 60 * 60 * 24 * 7) throw new Error('invalid_timestamp');
  if (expiresAtEpochMs != null && (!Number.isFinite(expiresAtEpochMs) || expiresAtEpochMs < nowMs())) throw new Error('invalid_expiration');

  const canonical = canonicalChatId(senderId, recipientId);
  const chatId = requestedChatId || canonical;
  if (chatId !== canonical) throw new Error('invalid_chat_id');

  return {
    chatId,
    messageId,
    senderId,
    recipientId,
    kind,
    encryptedPayload,
    iv,
    timestamp,
    protocolVersion,
    expiresAtEpochMs,
  };
}

async function upsertChatAndMessage(payload) {
  const chatRef = db.collection('chats').doc(payload.chatId);
  const msgRef = chatRef.collection('messages').doc(payload.messageId);
  const participants = [payload.senderId, payload.recipientId].sort();

  await db.runTransaction(async (tx) => {
    const existingMessage = await tx.get(msgRef);
    if (existingMessage.exists) {
      throw new Error('duplicate_message_id');
    }

    tx.set(chatRef, {
      chatId: payload.chatId,
      participants,
      isGroup: false,
      lastMessagePreview: 'Mensaje cifrado',
      lastMessageTimestamp: admin.firestore.FieldValue.serverTimestamp(),
      lastMessageEpochMs: payload.timestamp,
      lastMessageSenderId: payload.senderId,
      protocolVersion: payload.protocolVersion,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    }, { merge: true });

    tx.set(msgRef, {
      messageId: payload.messageId,
      chatId: payload.chatId,
      senderId: payload.senderId,
      recipientId: payload.recipientId,
      kind: payload.kind,
      encryptedPayload: payload.encryptedPayload,
      iv: payload.iv,
      timestamp: payload.timestamp,
      delivered: false,
      read: false,
      protocolVersion: payload.protocolVersion,
      serverReceivedAt: admin.firestore.FieldValue.serverTimestamp(),
      expiresAt: payload.expiresAtEpochMs ? admin.firestore.Timestamp.fromMillis(payload.expiresAtEpochMs) : null,
    });
  });

  return { chatId: payload.chatId, messageId: payload.messageId };
}

app.use((req, res, next) => {
  req.id = req.headers['x-request-id'] || requestId();
  res.setHeader('X-Request-Id', req.id);
  next();
});
app.use(corsMiddleware);
app.use(securityHeaders);

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: SERVICE_NAME, app: APP_NAME, mode: 'cloud-run-firestore-relay' });
});

app.get('/ready', async (_req, res) => {
  try {
    await db.collection('_health').doc('relay').set({ checkedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    res.json({ ok: true });
  } catch (error) {
    problem(res, 503, 'firestore_unavailable', error.message);
  }
});

app.get('/v1/relay/version', (_req, res) => {
  res.json({ ok: true, app: APP_NAME, service: SERVICE_NAME, protocolVersion: PROTOCOL_VERSION, maxCiphertextBytes: MAX_CIPHERTEXT_BYTES });
});

app.post('/v1/relay/users/me/bootstrap', authRequired, rateLimit({ windowMs: 60_000, max: 20 }), async (req, res) => {
  try {
    const uid = req.nexoraAuth.uid;
    const body = req.body || {};
    const name = sanitizeString(body.name, 80);
    const photoUrl = body.photoUrl == null ? null : sanitizeString(body.photoUrl, 2048);
    const publicKey = body.publicKey == null ? null : sanitizeString(body.publicKey, 4096);
    const fcmToken = body.fcmToken == null ? null : sanitizeString(body.fcmToken, 4096);

    await db.collection('users').doc(uid).set({
      uid,
      phone: req.nexoraAuth.phone_number || '',
      name,
      photoUrl,
      status: 'Disponible',
      publicKey,
      profileCompleted: name.length > 0,
      lastSeen: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    }, { merge: true });

    await upsertPublicProfile(uid, { name, photoUrl, status: 'Disponible', publicKey });

    if (fcmToken) {
      await db.collection('fcmTokens').doc(uid).set({ token: fcmToken, platform: 'android', updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    }

    res.json({ ok: true, uid });
  } catch (error) {
    log('error', 'bootstrap failed', { requestId: req.id, error: error.message });
    problem(res, 500, 'bootstrap_failed');
  }
});

app.post('/v1/relay/messages', authRequired, rateLimit({ windowMs: 60_000, max: 120 }), async (req, res) => {
  try {
    const payload = normalizeRelayPayload(req.body || {}, req.nexoraAuth.uid);
    const recipientExists = await assertUserExists(payload.recipientId);
    if (!recipientExists) return problem(res, 404, 'recipient_not_found');

    const result = await upsertChatAndMessage(payload);
    log('info', 'message accepted', { requestId: req.id, chatId: result.chatId, messageId: result.messageId, senderId: payload.senderId, recipientId: payload.recipientId, kind: payload.kind });
    res.status(202).json({ ok: true, accepted: true, ...result });
  } catch (error) {
    const clientErrors = new Set([
      'invalid_participants', 'same_sender_recipient', 'sender_mismatch', 'invalid_kind',
      'invalid_encrypted_payload', 'invalid_iv', 'invalid_timestamp', 'invalid_expiration',
      'invalid_chat_id', 'duplicate_message_id',
    ]);
    if (clientErrors.has(error.message)) {
      const status = error.message === 'sender_mismatch' ? 403 : error.message === 'duplicate_message_id' ? 409 : 400;
      return problem(res, status, error.message);
    }
    log('error', 'relay/messages failed', { requestId: req.id, error: error.message });
    problem(res, 500, 'relay_failed');
  }
});

app.get('/v1/relay/chats', authRequired, rateLimit({ windowMs: 60_000, max: 120 }), async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit || 100), 200);
    const snapshot = await db.collection('chats')
      .where('participants', 'array-contains', req.nexoraAuth.uid)
      .orderBy('lastMessageEpochMs', 'desc')
      .limit(limit)
      .get();
    res.json({ ok: true, chats: snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) });
  } catch (error) {
    log('error', 'relay/chats failed', { requestId: req.id, error: error.message });
    problem(res, 500, 'chats_fetch_failed');
  }
});

app.get('/v1/relay/chats/:chatId/messages', authRequired, rateLimit({ windowMs: 60_000, max: 240 }), async (req, res) => {
  try {
    const chatId = sanitizeString(req.params.chatId, 260);
    const chatDoc = await db.collection('chats').doc(chatId).get();
    if (!chatDoc.exists) return problem(res, 404, 'chat_not_found');

    const chat = chatDoc.data() || {};
    const participants = Array.isArray(chat.participants) ? chat.participants : [];
    if (!participants.includes(req.nexoraAuth.uid)) return problem(res, 403, 'forbidden');

    const since = req.query.since ? Number(req.query.since) : null;
    const limit = Math.min(Number(req.query.limit || 200), MAX_MESSAGES_LIMIT);

    let query = chatDoc.ref.collection('messages').orderBy('timestamp', 'asc').limit(limit);
    if (since) query = query.where('timestamp', '>', since);

    const snapshot = await query.get();
    const messages = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    res.json({ ok: true, chatId, messages });
  } catch (error) {
    log('error', 'relay/chats messages failed', { requestId: req.id, error: error.message });
    problem(res, 500, 'relay_fetch_failed');
  }
});

app.post('/v1/relay/ack', authRequired, rateLimit({ windowMs: 60_000, max: 240 }), async (req, res) => {
  try {
    const chatId = sanitizeString(req.body?.chatId, 260);
    const messageId = sanitizeString(req.body?.messageId, 128);
    const read = Boolean(req.body?.read);
    const delivered = req.body?.delivered == null ? true : Boolean(req.body.delivered);
    if (!chatId || !messageId) return problem(res, 400, 'missing_required_fields');

    const chatRef = db.collection('chats').doc(chatId);
    const msgRef = chatRef.collection('messages').doc(messageId);
    const [chatDoc, msgDoc] = await Promise.all([chatRef.get(), msgRef.get()]);
    if (!chatDoc.exists || !msgDoc.exists) return problem(res, 404, 'message_not_found');

    const chat = chatDoc.data() || {};
    const participants = Array.isArray(chat.participants) ? chat.participants : [];
    if (!participants.includes(req.nexoraAuth.uid)) return problem(res, 403, 'forbidden');

    const message = msgDoc.data() || {};
    if (message.recipientId !== req.nexoraAuth.uid) return problem(res, 403, 'ack_only_by_recipient');

    await msgRef.set({
      delivered,
      read,
      ackAt: admin.firestore.FieldValue.serverTimestamp(),
      ackBy: req.nexoraAuth.uid,
    }, { merge: true });

    res.json({ ok: true });
  } catch (error) {
    log('error', 'relay/ack failed', { requestId: req.id, error: error.message });
    problem(res, 500, 'ack_failed');
  }
});

app.use((req, res) => problem(res, 404, 'not_found', `${req.method} ${req.path}`));

app.use((error, req, res, _next) => {
  log('error', 'unhandled_error', { requestId: req.id, error: error.message });
  problem(res, 500, 'internal_error');
});

const port = process.env.PORT || 8080;
app.listen(port, () => {
  log('info', `Nexora relay API listening on ${port}`, { port });
});
