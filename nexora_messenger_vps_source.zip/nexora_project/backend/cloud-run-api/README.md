# Nexora Relay API

Relay HTTP para mensajes cifrados de Nexora. Se despliega en Cloud Run y usa Firebase Admin SDK para verificar Firebase ID Tokens.

## Ejecutar localmente

Necesitas credenciales de aplicación de Google configuradas:

```bash
export GOOGLE_APPLICATION_CREDENTIALS=/ruta/service-account.json
npm install
npm run dev
```

## Validar sintaxis

```bash
npm run check
```

## Desplegar

```bash
gcloud run deploy nexora-relay-api \
  --source . \
  --region us-central1 \
  --platform managed \
  --allow-unauthenticated
```

## Endpoints

- `GET /health`
- `GET /ready`
- `GET /v1/relay/version`
- `POST /v1/relay/users/me/bootstrap`
- `POST /v1/relay/messages`
- `GET /v1/relay/chats`
- `GET /v1/relay/chats/:chatId/messages`
- `POST /v1/relay/ack`

Todos los endpoints `/v1/relay/*` requieren:

```text
Authorization: Bearer <Firebase ID Token>
```

## Privacidad

El relay no acepta preview real desde el cliente. Siempre guarda `Mensaje cifrado` como preview para evitar fuga accidental de contenido.
