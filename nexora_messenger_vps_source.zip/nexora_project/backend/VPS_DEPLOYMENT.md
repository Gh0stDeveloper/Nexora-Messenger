# Nexora — Despliegue en VPS propio

Esta versión adapta Nexora para usar un servidor propio en VPS. El servidor queda en `backend/vps-api` y el despliegue operativo en `backend/vps`.

## Arquitectura

```text
Android Nexora
  ├─ Firebase Auth: OTP por teléfono y emisión de ID Token
  ├─ Firebase Cloud Messaging: push notification token
  └─ HTTPS API VPS: relay cifrado

VPS
  ├─ Nginx + TLS
  ├─ Node.js/Express relay API
  ├─ PostgreSQL
  └─ Docker Compose
```

El VPS **no descifra mensajes**. Solo valida el token, recibe `encryptedPayload + iv`, guarda el ciphertext y lo entrega al destinatario autenticado. Los avatares de perfil se guardan en el propio VPS bajo `/uploads/avatars`, no en Firebase Storage.

## 1. Preparar servidor Ubuntu/Debian

```bash
sudo bash backend/vps/scripts/install-vps.sh
```

Esto instala Docker, Docker Compose plugin, Nginx, Certbot y abre puertos 80/443.

## 2. Subir proyecto al VPS

```bash
sudo mkdir -p /opt/nexora
sudo chown -R $USER:$USER /opt/nexora
rsync -az ./ /opt/nexora/
```

## 3. Configurar variables

```bash
cd /opt/nexora/backend/vps
cp .env.example .env
nano .env
```

Cambia como mínimo:

```text
POSTGRES_PASSWORD=una_password_larga
DATABASE_URL=postgresql://nexora:una_password_larga@postgres:5432/nexora
FIREBASE_PROJECT_ID=tu-proyecto-firebase
APP_PUBLIC_BASE_URL=https://api.TU-DOMINIO.com
UPLOAD_DIR=/app/uploads
MAX_AVATAR_BYTES=2097152
```

## 4. Service account de Firebase Admin

Firebase Auth sigue siendo usado para OTP. El VPS necesita verificar los ID Tokens con Firebase Admin.

Coloca el archivo descargado desde Firebase/GCP en:

```text
backend/vps/secrets/firebase-service-account.json
```

No subas ese archivo a GitHub.

## 5. Levantar el backend

```bash
cd /opt/nexora/backend/vps
./scripts/deploy.sh
```

Prueba local en el VPS:

```bash
curl http://127.0.0.1:8080/health
curl http://127.0.0.1:8080/ready
```

## 6. Nginx + HTTPS

```bash
sudo cp nginx/nexora-api.conf /etc/nginx/sites-available/nexora-api.conf
sudo sed -i 's/api.tu-dominio.com/api.TU-DOMINIO.com/g' /etc/nginx/sites-available/nexora-api.conf
sudo ln -sf /etc/nginx/sites-available/nexora-api.conf /etc/nginx/sites-enabled/nexora-api.conf
sudo nginx -t
sudo systemctl reload nginx
sudo certbot --nginx -d api.TU-DOMINIO.com
```

## 7. Compilar Android apuntando al VPS

```bash
cd android
./gradlew :app:assembleDebug -PNEXORA_RELAY_BASE_URL=https://api.TU-DOMINIO.com
```

## 8. GitHub Actions para VPS

Configura secrets:

```text
VPS_HOST=IP_o_dominio_del_VPS
VPS_USER=usuario_ssh
VPS_SSH_KEY=llave_privada_ssh
VPS_APP_DIR=/opt/nexora
```

Ejecuta el workflow `Deploy VPS Relay` manualmente o al hacer push a `main` con cambios en `backend/vps-api` o `backend/vps`.

## 9. Backups

```bash
cd /opt/nexora/backend/vps
./scripts/backup-postgres.sh
```

Restaurar:

```bash
./scripts/restore-postgres.sh backups/nexora-YYYYmmdd-HHMMSS.sql.gz
```
