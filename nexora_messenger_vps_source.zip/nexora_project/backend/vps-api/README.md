# Nexora VPS Relay API

API principal para **Nexora Messenger** cuando se usa infraestructura propia en VPS.

El servidor valida Firebase ID Tokens, registra perfiles mínimos, guarda avatares en disco persistente del VPS, administra FCM tokens y actúa como relay de mensajes cifrados.

## Responsabilidad del servicio

- No descifra mensajes.
- No acepta texto plano como preview.
- No guarda avatares en Firebase Storage.
- No permite suplantar `senderId`.
- No permite marcar mensajes como leídos si el usuario autenticado no es destinatario.

## Endpoints

```text
GET  /health
GET  /ready
GET  /v1/relay/version
POST /v1/relay/users/me/bootstrap
POST /v1/relay/users/me/avatar
POST /v1/relay/users/me/fcm-token
GET  /v1/relay/users/:uid/public
POST /v1/relay/messages
GET  /v1/relay/chats
GET  /v1/relay/chats/:chatId/messages
POST /v1/relay/ack
```

Todos los endpoints `/v1/relay/*` requieren:

```text
Authorization: Bearer FIREBASE_ID_TOKEN
```

## Variables importantes

```env
PORT=8080
DATABASE_URL=postgresql://nexora:password@postgres:5432/nexora
FIREBASE_PROJECT_ID=tu-proyecto-firebase
GOOGLE_APPLICATION_CREDENTIALS=/run/secrets/firebase-service-account.json
APP_PUBLIC_BASE_URL=https://api.tu-dominio.com
UPLOAD_DIR=/app/uploads
MAX_AVATAR_BYTES=2097152
JSON_LIMIT=768kb
```

## Avatares

La app sube la foto de perfil a:

```text
POST /v1/relay/users/me/avatar
```

Formato:

```text
multipart/form-data
field: avatar
```

Tipos permitidos:

```text
image/jpeg
image/png
image/webp
```

Tamaño máximo por defecto:

```text
2 MB
```

El servidor responde:

```json
{
  "ok": true,
  "photoUrl": "https://api.tu-dominio.com/uploads/avatars/uid-timestamp-random.jpg"
}
```

## Verificación local

```bash
npm install
npm run check
npm start
```
