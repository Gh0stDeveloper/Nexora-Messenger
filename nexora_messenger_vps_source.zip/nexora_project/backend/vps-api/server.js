'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const express = require('express');
const multer = require('multer');
const admin = require('firebase-admin');
const { Pool } = require('pg');

const APP_NAME = 'Nexora';
const SERVICE_NAME = 'nexora-vps-relay-api';
const PROTOCOL_VERSION = 'nexora-e2ee-v1';
const MAX_CIPHERTEXT_BYTES = Number(process.env.MAX_CIPHERTEXT_BYTES || 512 * 1024);
const MAX_MESSAGES_LIMIT = Number(process.env.MAX_MESSAGES_LIMIT || 300);
const MAX_AVATAR_BYTES = Number(process.env.MAX_AVATAR_BYTES || 2 * 1024 * 1024);
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(process.cwd(), 'uploads');
const AVATAR_DIR = path.join(UPLOAD_DIR, 'avatars');
const RATE_LIMIT_WINDOW_MS = Number(process.env.RATE_LIMIT_WINDOW_MS || 60_000);
const RATE_LIMIT_AUTH_MAX = Number(process.env.RATE_LIMIT_AUTH_MAX || 120);
const RATE_LIMIT_READ_MAX = Number(process.env.RATE_LIMIT_READ_MAX || 240);
const ALLOWED_KINDS = new Set(['TEXT', 'IMAGE', 'AUDIO', 'VIDEO', 'DOCUMENT']);
const rateBuckets = new Map();

function nowMs() { return Date.now(); }
function requestId() { return crypto.randomUUID(); }
function canonicalChatId(a, b) { return [String(a), String(b)].sort().join('_'); }
function sanitizeString(value, maxLength) { return String(value || '').trim().slice(0, maxLength); }
function ensureUploadDirs() { fs.mkdirSync(AVATAR_DIR, { recursive: true }); }
function safeAvatarExtension(mimetype) {
  if (mimetype === 'image/png') return '.png';
  if (mimetype === 'image/webp') return '.webp';
  return '.jpg';
}
function publicBaseUrl(req) {
  return (process.env.APP_PUBLIC_BASE_URL || `${req.protocol}://${req.get('host')}`).replace(/\/$/, '');
}
function avatarUrlFor(req, fileName) { return `${publicBaseUrl(req)}/uploads/avatars/${fileName}`; }
function log(level, message, data = {}) {
  const payload = { level, message, service: SERVICE_NAME, ...data };
  const line = JSON.stringify(payload);
  if (level === 'error') console.error(line);
  else if (level === 'warn') console.warn(line);
  else console.log(line);
}
function problem(res, status, code, details = undefined) { return res.status(status).json({ ok: false, error: code, details }); }

function parseFirebaseCredential() {
  const rawJson = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  const rawB64 = process.env.FIREBASE_SERVICE_ACCOUNT_BASE64;
  if (rawJson) return JSON.parse(rawJson);
  if (rawB64) return JSON.parse(Buffer.from(rawB64, 'base64').toString('utf8'));
  return null;
}
function initializeFirebaseAdmin() {
  if (admin.apps.length > 0) return;
  const serviceAccount = parseFirebaseCredential();
  const options = {};
  if (serviceAccount) options.credential = admin.credential.cert(serviceAccount);
  if (process.env.FIREBASE_PROJECT_ID) options.projectId = process.env.FIREBASE_PROJECT_ID;
  admin.initializeApp(options);
}
initializeFirebaseAdmin();
ensureUploadDirs();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: Number(process.env.PG_POOL_MAX || 10),
  idleTimeoutMillis: Number(process.env.PG_IDLE_TIMEOUT_MS || 30_000),
  connectionTimeoutMillis: Number(process.env.PG_CONNECT_TIMEOUT_MS || 10_000),
});

const avatarUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, AVATAR_DIR),
    filename: (req, file, cb) => {
      const uid = req.nexoraAuth?.uid || 'unknown';
      const suffix = crypto.randomBytes(8).toString('hex');
      cb(null, `${uid}-${Date.now()}-${suffix}${safeAvatarExtension(file.mimetype)}`);
    },
  }),
  limits: { fileSize: MAX_AVATAR_BYTES, files: 1 },
  fileFilter: (_req, file, cb) => {
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.mimetype)) {
      return cb(new Error('invalid_avatar_type'));
    }
    cb(null, true);
  },
});

async function migrate() {
  const sql = `
CREATE TABLE IF NOT EXISTS users (
  uid TEXT PRIMARY KEY,
  phone TEXT NOT NULL DEFAULT '',
  name TEXT NOT NULL DEFAULT '',
  photo_url TEXT,
  status TEXT NOT NULL DEFAULT 'Disponible',
  public_key TEXT,
  fcm_token TEXT,
  fcm_platform TEXT NOT NULL DEFAULT 'android',
  profile_completed BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_seen TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS chats (
  chat_id TEXT PRIMARY KEY,
  participants TEXT[] NOT NULL,
  is_group BOOLEAN NOT NULL DEFAULT FALSE,
  last_message_preview TEXT NOT NULL DEFAULT 'Mensaje cifrado',
  last_message_epoch_ms BIGINT NOT NULL DEFAULT 0,
  last_message_sender_id TEXT NOT NULL DEFAULT '',
  protocol_version TEXT NOT NULL DEFAULT '${PROTOCOL_VERSION}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS messages (
  chat_id TEXT NOT NULL REFERENCES chats(chat_id) ON DELETE CASCADE,
  message_id TEXT NOT NULL,
  sender_id TEXT NOT NULL,
  recipient_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  encrypted_payload TEXT NOT NULL,
  iv TEXT NOT NULL,
  timestamp_ms BIGINT NOT NULL,
  delivered BOOLEAN NOT NULL DEFAULT FALSE,
  read BOOLEAN NOT NULL DEFAULT FALSE,
  protocol_version TEXT NOT NULL DEFAULT '${PROTOCOL_VERSION}',
  expires_at TIMESTAMPTZ,
  server_received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ack_at TIMESTAMPTZ,
  ack_by TEXT,
  PRIMARY KEY (chat_id, message_id)
);
CREATE INDEX IF NOT EXISTS idx_chats_participants ON chats USING GIN(participants);
CREATE INDEX IF NOT EXISTS idx_chats_last_message ON chats(last_message_epoch_ms DESC);
CREATE INDEX IF NOT EXISTS idx_messages_chat_timestamp ON messages(chat_id, timestamp_ms ASC);
CREATE INDEX IF NOT EXISTS idx_messages_recipient ON messages(recipient_id, timestamp_ms DESC);
CREATE INDEX IF NOT EXISTS idx_messages_expires_at ON messages(expires_at) WHERE expires_at IS NOT NULL;
`;
  await pool.query(sql);
}

function isLikelyBase64(value) {
  if (typeof value !== 'string' || value.length < 8) return false;
  if (Buffer.byteLength(value, 'utf8') > MAX_CIPHERTEXT_BYTES * 2) return false;
  return /^[A-Za-z0-9+/=_-]+$/.test(value);
}
function isValidUid(value) { return typeof value === 'string' && value.length >= 8 && value.length <= 128 && /^[A-Za-z0-9:_-]+$/.test(value); }

function corsMiddleware(req, res, next) {
  const allowedOrigins = (process.env.CORS_ORIGINS || '').split(',').map((origin) => origin.trim()).filter(Boolean);
  const origin = req.headers.origin;
  if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
    if (origin) res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type, X-Request-Id');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  }
  if (req.method === 'OPTIONS') return res.status(204).end();
  next();
}
function securityHeaders(_req, res, next) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-site');
  next();
}
function rateLimit({ windowMs = RATE_LIMIT_WINDOW_MS, max }) {
  return (req, res, next) => {
    const id = req.nexoraAuth?.uid || req.ip || 'anonymous';
    const key = `${req.method}:${req.path}:${id}`;
    const current = rateBuckets.get(key) || { count: 0, resetAt: nowMs() + windowMs };
    if (nowMs() > current.resetAt) { current.count = 0; current.resetAt = nowMs() + windowMs; }
    current.count += 1;
    rateBuckets.set(key, current);
    res.setHeader('X-RateLimit-Limit', String(max));
    res.setHeader('X-RateLimit-Remaining', String(Math.max(0, max - current.count)));
    res.setHeader('X-RateLimit-Reset', String(Math.floor(current.resetAt / 1000)));
    if (current.count > max) return problem(res, 429, 'rate_limited');
    next();
  };
}
setInterval(() => {
  const now = nowMs();
  for (const [key, bucket] of rateBuckets.entries()) if (now > bucket.resetAt + 60_000) rateBuckets.delete(key);
}, 60_000).unref();
setInterval(async () => {
  try {
    const result = await pool.query('DELETE FROM messages WHERE expires_at IS NOT NULL AND expires_at < NOW()');
    if (result.rowCount > 0) log('info', 'expired messages purged', { deleted: result.rowCount });
  } catch (error) { log('warn', 'purge expired messages failed', { error: error.message }); }
}, Number(process.env.PURGE_INTERVAL_MS || 60 * 60 * 1000)).unref();

async function authRequired(req, res, next) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');
  if (scheme !== 'Bearer' || !token) return problem(res, 401, 'missing_bearer_token');
  try {
    req.nexoraAuth = await admin.auth().verifyIdToken(token, true);
    next();
  } catch (error) {
    log('warn', 'verifyIdToken failed', { requestId: req.id, error: error.message });
    problem(res, 401, 'invalid_token');
  }
}

function normalizeRelayPayload(body, authUid) {
  const senderId = sanitizeString(body.senderId, 128);
  const recipientId = sanitizeString(body.recipientId, 128);
  const kind = sanitizeString(body.kind || 'TEXT', 24).toUpperCase();
  const encryptedPayload = String(body.encryptedPayload || '');
  const iv = String(body.iv || '');
  const requestedChatId = sanitizeString(body.chatId, 260);
  const messageId = sanitizeString(body.messageId || `msg_${nowMs()}_${crypto.randomUUID().slice(0, 8)}`, 128);
  const protocolVersion = sanitizeString(body.protocolVersion || PROTOCOL_VERSION, 64);
  const timestamp = Number(body.timestamp || nowMs());
  const expiresAtEpochMs = body.expiresAtEpochMs == null ? null : Number(body.expiresAtEpochMs);
  if (!isValidUid(senderId) || !isValidUid(recipientId)) throw new Error('invalid_participants');
  if (senderId === recipientId) throw new Error('same_sender_recipient');
  if (authUid !== senderId) throw new Error('sender_mismatch');
  if (!ALLOWED_KINDS.has(kind)) throw new Error('invalid_kind');
  if (!isLikelyBase64(encryptedPayload)) throw new Error('invalid_encrypted_payload');
  if (!isLikelyBase64(iv) || iv.length > 256) throw new Error('invalid_iv');
  if (!Number.isFinite(timestamp) || Math.abs(nowMs() - timestamp) > 1000 * 60 * 60 * 24 * 7) throw new Error('invalid_timestamp');
  if (expiresAtEpochMs != null && (!Number.isFinite(expiresAtEpochMs) || expiresAtEpochMs < nowMs())) throw new Error('invalid_expiration');
  const canonical = canonicalChatId(senderId, recipientId);
  const chatId = requestedChatId || canonical;
  if (chatId !== canonical) throw new Error('invalid_chat_id');
  return { chatId, messageId, senderId, recipientId, kind, encryptedPayload, iv, timestamp, protocolVersion, expiresAtEpochMs };
}

async function ensureRecipientExists(client, uid) {
  const result = await client.query('SELECT uid FROM users WHERE uid = $1 LIMIT 1', [uid]);
  return result.rowCount > 0;
}
async function sendEncryptedMessageNotification(client, recipientId) {
  try {
    const result = await client.query('SELECT fcm_token FROM users WHERE uid = $1 AND fcm_token IS NOT NULL LIMIT 1', [recipientId]);
    const token = result.rows[0]?.fcm_token;
    if (!token) return;
    await admin.messaging().send({
      token,
      notification: { title: 'Nexora', body: 'Nuevo mensaje cifrado' },
      data: { type: 'message', privacy: 'e2ee' },
      android: { priority: 'high' },
    });
  } catch (error) {
    log('warn', 'FCM notification failed', { recipientId, error: error.message });
  }
}
async function upsertChatAndMessage(payload) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const recipientExists = await ensureRecipientExists(client, payload.recipientId);
    if (!recipientExists) throw new Error('recipient_not_found');
    const participants = [payload.senderId, payload.recipientId].sort();
    await client.query(`
      INSERT INTO chats(chat_id, participants, is_group, last_message_preview, last_message_epoch_ms, last_message_sender_id, protocol_version, updated_at)
      VALUES($1, $2, false, 'Mensaje cifrado', $3, $4, $5, NOW())
      ON CONFLICT(chat_id) DO UPDATE SET
        participants = EXCLUDED.participants,
        last_message_preview = 'Mensaje cifrado',
        last_message_epoch_ms = EXCLUDED.last_message_epoch_ms,
        last_message_sender_id = EXCLUDED.last_message_sender_id,
        protocol_version = EXCLUDED.protocol_version,
        updated_at = NOW()
    `, [payload.chatId, participants, payload.timestamp, payload.senderId, payload.protocolVersion]);
    const insert = await client.query(`
      INSERT INTO messages(chat_id, message_id, sender_id, recipient_id, kind, encrypted_payload, iv, timestamp_ms, delivered, read, protocol_version, expires_at)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,false,false,$9, CASE WHEN $10::BIGINT IS NULL THEN NULL ELSE TO_TIMESTAMP($10::BIGINT / 1000.0) END)
      ON CONFLICT(chat_id, message_id) DO NOTHING
    `, [payload.chatId, payload.messageId, payload.senderId, payload.recipientId, payload.kind, payload.encryptedPayload, payload.iv, payload.timestamp, payload.protocolVersion, payload.expiresAtEpochMs]);
    if (insert.rowCount === 0) throw new Error('duplicate_message_id');
    await client.query('COMMIT');
    await sendEncryptedMessageNotification(client, payload.recipientId);
    return { chatId: payload.chatId, messageId: payload.messageId };
  } catch (error) {
    await client.query('ROLLBACK').catch(() => undefined);
    throw error;
  } finally {
    client.release();
  }
}
function rowToChat(row, uid) {
  const participants = Array.isArray(row.participants) ? row.participants : [];
  const peerId = participants.find((item) => item !== uid) || uid;
  return {
    chatId: row.chat_id,
    participants,
    isGroup: row.is_group,
    peerId,
    peerName: row.peer_name || 'Contacto',
    peerPhotoUrl: row.peer_photo_url || null,
    lastMessagePreview: row.last_message_preview || 'Mensaje cifrado',
    lastMessageEpochMs: Number(row.last_message_epoch_ms || 0),
    lastMessageSenderId: row.last_message_sender_id || '',
    protocolVersion: row.protocol_version || PROTOCOL_VERSION,
    updatedAt: row.updated_at,
  };
}
function rowToMessage(row) {
  return {
    messageId: row.message_id,
    chatId: row.chat_id,
    senderId: row.sender_id,
    recipientId: row.recipient_id,
    kind: row.kind,
    encryptedPayload: row.encrypted_payload,
    iv: row.iv,
    timestamp: Number(row.timestamp_ms || 0),
    delivered: Boolean(row.delivered),
    read: Boolean(row.read),
    protocolVersion: row.protocol_version || PROTOCOL_VERSION,
    serverReceivedAt: row.server_received_at,
  };
}

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', true);
app.use(express.json({ limit: process.env.JSON_LIMIT || '768kb' }));
app.use((req, res, next) => { req.id = req.headers['x-request-id'] || requestId(); res.setHeader('X-Request-Id', req.id); next(); });
app.use(corsMiddleware);
app.use(securityHeaders);
app.use('/uploads', express.static(UPLOAD_DIR, {
  fallthrough: false,
  immutable: true,
  maxAge: '30d',
  setHeaders: (res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
  },
}));

app.get('/health', (_req, res) => res.json({ ok: true, service: SERVICE_NAME, app: APP_NAME, mode: 'vps-postgres-relay' }));
app.get('/ready', async (_req, res) => {
  try { await pool.query('SELECT 1'); res.json({ ok: true }); }
  catch (error) { problem(res, 503, 'postgres_unavailable', error.message); }
});
app.get('/v1/relay/version', (_req, res) => res.json({ ok: true, app: APP_NAME, service: SERVICE_NAME, protocolVersion: PROTOCOL_VERSION, maxCiphertextBytes: MAX_CIPHERTEXT_BYTES }));

app.post('/v1/relay/users/me/bootstrap', authRequired, rateLimit({ max: RATE_LIMIT_AUTH_MAX }), async (req, res) => {
  try {
    const uid = req.nexoraAuth.uid;
    const body = req.body || {};
    const phone = sanitizeString(req.nexoraAuth.phone_number || body.phone, 40);
    const name = sanitizeString(body.name, 80);
    const photoUrl = body.photoUrl == null ? null : sanitizeString(body.photoUrl, 2048);
    const publicKey = body.publicKey == null ? null : sanitizeString(body.publicKey, 4096);
    const fcmToken = body.fcmToken == null ? null : sanitizeString(body.fcmToken, 4096);
    const result = await pool.query(`
      INSERT INTO users(uid, phone, name, photo_url, status, public_key, fcm_token, fcm_platform, profile_completed, updated_at, last_seen)
      VALUES($1,$2,$3,$4,'Disponible',$5,$6,'android',($3 <> ''),NOW(),NOW())
      ON CONFLICT(uid) DO UPDATE SET
        phone = COALESCE(NULLIF(EXCLUDED.phone, ''), users.phone),
        name = COALESCE(NULLIF(EXCLUDED.name, ''), users.name),
        photo_url = COALESCE(EXCLUDED.photo_url, users.photo_url),
        public_key = COALESCE(EXCLUDED.public_key, users.public_key),
        fcm_token = COALESCE(EXCLUDED.fcm_token, users.fcm_token),
        profile_completed = (COALESCE(NULLIF(EXCLUDED.name, ''), users.name) <> ''),
        updated_at = NOW(),
        last_seen = NOW()
      RETURNING uid, phone, name, photo_url, status, public_key, profile_completed
    `, [uid, phone, name, photoUrl, publicKey, fcmToken]);
    res.json({ ok: true, user: result.rows[0] });
  } catch (error) {
    log('error', 'bootstrap failed', { requestId: req.id, error: error.message });
    problem(res, 500, 'bootstrap_failed');
  }
});


app.post('/v1/relay/users/me/avatar', authRequired, rateLimit({ max: RATE_LIMIT_AUTH_MAX }), (req, res) => {
  avatarUpload.single('avatar')(req, res, async (uploadError) => {
    if (uploadError) {
      const status = uploadError.message === 'invalid_avatar_type' || uploadError.code === 'LIMIT_FILE_SIZE' ? 400 : 500;
      return problem(res, status, uploadError.code || uploadError.message || 'avatar_upload_failed');
    }
    try {
      if (!req.file) return problem(res, 400, 'missing_avatar');
      const url = avatarUrlFor(req, req.file.filename);
      await pool.query(`
        INSERT INTO users(uid, phone, photo_url, updated_at, last_seen)
        VALUES($1,$2,$3,NOW(),NOW())
        ON CONFLICT(uid) DO UPDATE SET photo_url = EXCLUDED.photo_url, updated_at = NOW(), last_seen = NOW()
      `, [req.nexoraAuth.uid, sanitizeString(req.nexoraAuth.phone_number, 40), url]);
      res.json({ ok: true, photoUrl: url });
    } catch (error) {
      log('error', 'avatar upload failed', { requestId: req.id, error: error.message });
      problem(res, 500, 'avatar_upload_failed');
    }
  });
});

app.post('/v1/relay/users/me/fcm-token', authRequired, rateLimit({ max: RATE_LIMIT_AUTH_MAX }), async (req, res) => {
  try {
    const token = sanitizeString(req.body?.token, 4096);
    if (!token) return problem(res, 400, 'missing_token');
    await pool.query(`
      INSERT INTO users(uid, phone, fcm_token, fcm_platform, updated_at, last_seen)
      VALUES($1,$2,$3,'android',NOW(),NOW())
      ON CONFLICT(uid) DO UPDATE SET fcm_token = EXCLUDED.fcm_token, fcm_platform = 'android', updated_at = NOW(), last_seen = NOW()
    `, [req.nexoraAuth.uid, sanitizeString(req.nexoraAuth.phone_number, 40), token]);
    res.json({ ok: true });
  } catch (error) {
    log('error', 'fcm token failed', { requestId: req.id, error: error.message });
    problem(res, 500, 'fcm_token_failed');
  }
});

app.get('/v1/relay/users/:uid/public', authRequired, rateLimit({ max: RATE_LIMIT_READ_MAX }), async (req, res) => {
  try {
    const uid = sanitizeString(req.params.uid, 128);
    const result = await pool.query('SELECT uid, name, photo_url AS "photoUrl", status, public_key AS "publicKey" FROM users WHERE uid = $1 LIMIT 1', [uid]);
    if (result.rowCount === 0) return problem(res, 404, 'user_not_found');
    res.json({ ok: true, user: result.rows[0] });
  } catch (error) {
    log('error', 'public user failed', { requestId: req.id, error: error.message });
    problem(res, 500, 'public_user_failed');
  }
});

app.post('/v1/relay/messages', authRequired, rateLimit({ max: RATE_LIMIT_AUTH_MAX }), async (req, res) => {
  try {
    const payload = normalizeRelayPayload(req.body || {}, req.nexoraAuth.uid);
    const result = await upsertChatAndMessage(payload);
    log('info', 'message accepted', { requestId: req.id, chatId: result.chatId, messageId: result.messageId, senderId: payload.senderId, recipientId: payload.recipientId, kind: payload.kind });
    res.status(202).json({ ok: true, accepted: true, ...result });
  } catch (error) {
    const clientErrors = new Set(['invalid_participants','same_sender_recipient','sender_mismatch','invalid_kind','invalid_encrypted_payload','invalid_iv','invalid_timestamp','invalid_expiration','invalid_chat_id','duplicate_message_id','recipient_not_found']);
    if (clientErrors.has(error.message)) {
      const status = error.message === 'sender_mismatch' ? 403 : error.message === 'duplicate_message_id' ? 409 : error.message === 'recipient_not_found' ? 404 : 400;
      return problem(res, status, error.message);
    }
    log('error', 'relay/messages failed', { requestId: req.id, error: error.message });
    problem(res, 500, 'relay_failed');
  }
});

app.get('/v1/relay/chats', authRequired, rateLimit({ max: RATE_LIMIT_READ_MAX }), async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit || 100), 200);
    const uid = req.nexoraAuth.uid;
    const result = await pool.query(`
      SELECT c.*, u.name AS peer_name, u.photo_url AS peer_photo_url
      FROM chats c
      LEFT JOIN users u ON u.uid = CASE WHEN c.participants[1] = $1 THEN c.participants[2] ELSE c.participants[1] END
      WHERE c.participants @> ARRAY[$1]::text[]
      ORDER BY c.last_message_epoch_ms DESC
      LIMIT $2
    `, [uid, limit]);
    res.json({ ok: true, chats: result.rows.map((row) => rowToChat(row, uid)) });
  } catch (error) {
    log('error', 'relay/chats failed', { requestId: req.id, error: error.message });
    problem(res, 500, 'chats_fetch_failed');
  }
});

app.get('/v1/relay/chats/:chatId/messages', authRequired, rateLimit({ max: RATE_LIMIT_READ_MAX }), async (req, res) => {
  try {
    const chatId = sanitizeString(req.params.chatId, 260);
    const uid = req.nexoraAuth.uid;
    const since = req.query.since ? Number(req.query.since) : null;
    const limit = Math.min(Number(req.query.limit || 200), MAX_MESSAGES_LIMIT);
    const chat = await pool.query('SELECT participants FROM chats WHERE chat_id = $1 AND participants @> ARRAY[$2]::text[] LIMIT 1', [chatId, uid]);
    if (chat.rowCount === 0) return problem(res, 404, 'chat_not_found');
    const result = await pool.query(`
      SELECT * FROM messages
      WHERE chat_id = $1 AND ($2::BIGINT IS NULL OR timestamp_ms > $2)
      ORDER BY timestamp_ms ASC
      LIMIT $3
    `, [chatId, since, limit]);
    res.json({ ok: true, chatId, messages: result.rows.map(rowToMessage) });
  } catch (error) {
    log('error', 'relay/chats messages failed', { requestId: req.id, error: error.message });
    problem(res, 500, 'relay_fetch_failed');
  }
});

app.post('/v1/relay/ack', authRequired, rateLimit({ max: RATE_LIMIT_READ_MAX }), async (req, res) => {
  try {
    const chatId = sanitizeString(req.body?.chatId, 260);
    const messageId = sanitizeString(req.body?.messageId, 128);
    const read = Boolean(req.body?.read);
    const delivered = req.body?.delivered == null ? true : Boolean(req.body.delivered);
    if (!chatId || !messageId) return problem(res, 400, 'missing_required_fields');
    const result = await pool.query(`
      UPDATE messages
      SET delivered = $1, read = $2, ack_at = NOW(), ack_by = $3
      WHERE chat_id = $4 AND message_id = $5 AND recipient_id = $3
      RETURNING message_id
    `, [delivered, read, req.nexoraAuth.uid, chatId, messageId]);
    if (result.rowCount === 0) return problem(res, 404, 'message_not_found_or_not_recipient');
    res.json({ ok: true });
  } catch (error) {
    log('error', 'relay/ack failed', { requestId: req.id, error: error.message });
    problem(res, 500, 'ack_failed');
  }
});

app.use((req, res) => problem(res, 404, 'not_found', `${req.method} ${req.path}`));
app.use((error, req, res, _next) => { log('error', 'unhandled_error', { requestId: req.id, error: error.message }); problem(res, 500, 'internal_error'); });

const port = Number(process.env.PORT || 8080);
migrate().then(() => {
  app.listen(port, () => log('info', `Nexora VPS relay API listening on ${port}`, { port }));
}).catch((error) => {
  log('error', 'startup failed', { error: error.message });
  process.exit(1);
});
